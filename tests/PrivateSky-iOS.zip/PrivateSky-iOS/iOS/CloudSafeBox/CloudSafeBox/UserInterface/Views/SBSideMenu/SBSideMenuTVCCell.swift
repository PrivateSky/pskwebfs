import UIKit

class SBSideMenuTVCCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet private weak var selectedView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        selectedView.backgroundColor = selected ? UIColor.highlight() : UIColor.clear
        titleLabel.textColor = UIColor.white
    }
    
    func setup(withTitle title: String) {
        self.titleLabel.text = title
    }
    
    static func reuseId() -> String {
        return "SBSideMenuTVCCellReuseIdentifier"
    }
}
