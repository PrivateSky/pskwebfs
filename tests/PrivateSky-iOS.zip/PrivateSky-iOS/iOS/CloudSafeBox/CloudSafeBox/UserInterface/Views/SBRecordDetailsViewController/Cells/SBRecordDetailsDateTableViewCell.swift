import UIKit

struct SBRecordDetailsDateTVCViewModel {
    let sectionName: String
    let date: Date?
    let onContentChange: ((_ newContent: Date) -> Void)?
}

class SBRecordDetailsDateTableViewCell: UITableViewCell {
    
    private var viewModel: SBRecordDetailsDateTVCViewModel?
    
    @IBOutlet weak var sectionNameLabel: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBAction func changeDate(_ sender: Any) {
        viewModel?.onContentChange?(datePicker.date)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        addCustomSeparatorView()
        sectionNameLabel.textColor = .generalText()
    }
    
    func setup(with viewModel: SBRecordDetailsDateTVCViewModel?) {
        guard let viewModel = viewModel else { return }
        self.viewModel = viewModel
        sectionNameLabel.text = viewModel.sectionName
        datePicker.date = viewModel.date ?? Date()
    }
    
    static func reuseId() -> String {
        return "SBRecordDetailsDateTableViewCellReuseIdentifier"
    }
}
