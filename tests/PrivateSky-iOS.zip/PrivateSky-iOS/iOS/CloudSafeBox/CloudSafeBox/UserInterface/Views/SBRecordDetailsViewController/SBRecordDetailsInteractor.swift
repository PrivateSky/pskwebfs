import UIKit
import CloudSafeBoxCore

enum SBRecordDetailsVCState {
    case display
    case edit
    case new
}

struct SBRecordDetailsVCViewModel {
    let title: String
    var fields: [(key: String, value: Data, dataType: CSBRecordDataType)]
    var completion: (_ updatedFields: [(key: String, value: Data, dataType: CSBRecordDataType)]) -> Void
}

protocol SBRecordDetailsInteractorProtocol {
    
    func screenTitle() -> String
    func viewDidLoad()
    
    func numberOfSections() -> Int
    func numberOfRows(inSection section: Int) -> Int
    func cell(forRowAt indexPath: IndexPath, in tableView: UITableView) -> UITableViewCell?
    
    func dismiss()
    func edit()
}

class SBRecordDetailsInteractor: NSObject {
    
    private weak var view: SBRecordDetailsViewController?
    private var router: SBRecordDetailsRouter
    private var viewModel: SBRecordDetailsVCViewModel
    private var state: SBRecordDetailsVCState
    
    init(view: SBRecordDetailsViewController?, viewModel: SBRecordDetailsVCViewModel, state: SBRecordDetailsVCState = .display) {
        self.view = view
        self.router = SBRecordDetailsRouter(view: view)
        self.viewModel = viewModel
        self.state = state
        super.init()
    }
}

extension SBRecordDetailsInteractor: SBRecordDetailsInteractorProtocol {
    
    func screenTitle() -> String {
        return viewModel.title
    }
    
    func viewDidLoad() {
        view?.setEditIcon(forState: state)
    }
    
    func numberOfSections() -> Int {
        return 1
    }
    
    func numberOfRows(inSection section: Int) -> Int {
        return viewModel.fields.count
    }
    
    func cell(forRowAt indexPath: IndexPath, in tableView: UITableView) -> UITableViewCell? {
        let currentObject = viewModel.fields[indexPath.row]
        if state == .display {
            let cell = tableView.dequeueReusableCell(withIdentifier: SBRecordDetailsDisplayTableViewCell.reuseId(),
                                                     for: indexPath) as! SBRecordDetailsDisplayTableViewCell
            let model = SBRecordDetailsDisplayTVCViewModel(sectionName: currentObject.key,
                                                           content: String(data: currentObject.value,
                                                                           encoding: String.Encoding.utf8))
            cell.setup(with: model)
            return cell
        } else {
            switch currentObject.dataType {
            case .text:
                let cell = tableView.dequeueReusableCell(withIdentifier: SBRecordDetailsTextTableViewCell.reuseId(),
                                                         for: indexPath) as! SBRecordDetailsTextTableViewCell
                let model = SBRecordDetailsTextTVCViewModel(sectionName: currentObject.key,
                                                            content: String(data: currentObject.value,
                                                                            encoding: .utf8)) { [weak self] (value) in
                                                                                guard let strongSelf = self, let data = value.data(using: .utf8) else { return }
                                                                                strongSelf.viewModel.fields[indexPath.row].value = data
                                                                                print("text")
                }
                cell.setup(with: model)
                return cell
            case .date:
                let cell = tableView.dequeueReusableCell(withIdentifier: SBRecordDetailsDateTableViewCell.reuseId(),
                                                         for: indexPath) as! SBRecordDetailsDateTableViewCell
                let dateString = String(data: currentObject.value, encoding: String.Encoding.utf8)
                let date = dateString?.toDate(dateFormat: SBDateFormat.dateFormat.rawValue)
                let model = SBRecordDetailsDateTVCViewModel(sectionName: currentObject.key,
                                                            date: date) { [weak self] (date) in
                                                                let stringDate = date.stringDate(dateFormat: SBDateFormat.dateFormat.rawValue)
                                                                guard let strongSelf = self, let data = stringDate.data(using: .utf8) else { return }
                                                                strongSelf.viewModel.fields[indexPath.row].value = data
                                                                print("date")
                }
                cell.setup(with: model)
                return cell
            case .document:
                let cell = tableView.dequeueReusableCell(withIdentifier: SBRecordDetailsDocTableViewCell.reuseId(),
                                                         for: indexPath) as! SBRecordDetailsDocTableViewCell
                return cell
            }
        }
    }
    
    func dismiss() {
        router.perform(segue: .cancel, withTransitionObject: nil)
    }
    
    func edit() {
        switch state {
        case .display:
            state = .edit
        case .edit:
            state = .display
            viewModel.completion(viewModel.fields)
        case .new:
            viewModel.completion(viewModel.fields)
            dismiss()
        }
        view?.reloadData()
        view?.setEditIcon(forState: state)
    }
}
