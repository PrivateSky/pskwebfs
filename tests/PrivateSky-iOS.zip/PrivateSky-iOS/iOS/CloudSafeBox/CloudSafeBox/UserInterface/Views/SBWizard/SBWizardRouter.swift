import UIKit

enum SBWizardVCSegue {
    case csbList
}

class SBWizardRouter: NSObject {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController?) {
        self.view = view
    }
    
    func perform(segue: SBWizardVCSegue, withTransitionObject object: Any?) {
        switch segue {
        case .csbList:
            let nc = SBControllersContainer.menuHostViewController
            weak var weakSource = view
            view?.present(nc, animated: true, completion: {
                _ = weakSource?.navigationController?.popToRootViewController(animated: false)
            })
        }
    }
}
