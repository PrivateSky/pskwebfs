import UIKit

struct SBWizardOverlayViewViewModel {
    let onSkip: () -> ()
    let onNext: () -> ()
}

class SBWizardOverlayView: SwiftyOnboardOverlay {

    private var model: SBWizardOverlayViewViewModel?
    
    @IBOutlet weak var skip: UIButton!
    @IBOutlet weak var buttonContinue: UIButton!
    @IBOutlet weak var contentControl: UIPageControl!
    
    @IBAction func skip(_ sender: Any) {
        model?.onSkip()
    }
    
    @IBAction func next(_ sender: Any) {
        model?.onNext()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        continueButton.layer.borderColor = UIColor.white.cgColor
        continueButton.layer.borderWidth = 1
        continueButton.layer.cornerRadius = continueButton.bounds.height / 2
    }
    
    func setup(withModel model: SBWizardOverlayViewViewModel?) {
        self.model = model
    }
    
    class func instanceFromNib() -> UIView {
        return UINib(nibName: "SBWizardOverlayView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
}
