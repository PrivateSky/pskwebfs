//
//  SBGenericListRouter.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/4/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

enum SBRecordDetailsVCSegue {
    case cancel
    case editField
}

class SBRecordDetailsRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController?) {
        self.view = view
    }
    
    func perform(segue: SBRecordDetailsVCSegue, withTransitionObject object: Any?) {
        switch segue {
        case .cancel:
            view?.navigationController?.popViewController(animated: true)
        case .editField:
            print("")
        }
    }
}
