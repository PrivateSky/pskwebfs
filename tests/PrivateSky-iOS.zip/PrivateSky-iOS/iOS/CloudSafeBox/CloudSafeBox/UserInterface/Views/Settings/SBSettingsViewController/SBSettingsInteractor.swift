import UIKit

protocol SBSettingsInteractorProtocol {
    func numberOfSections() -> Int
    func numberOfRows(inSection section: Int) -> Int
    func viewModel(forRowAt indexPath: IndexPath) -> SBSettingsTVCViewModel?
    func titleForHeader(in section: Int) -> String
    func didSelect(rowAt indexPath: IndexPath)
}

enum SBSettingsVCSegue {
    case csbPreferences
}

class SBSettingsInteractor {
    
    private weak var view: SBSettingsViewController?
    private let dataSource: Dictionary<String, Array<(segue: SBSettingsVCSegue, model: SBSettingsTVCViewModel)>>
    
    init(withView view: SBSettingsViewController?) {
        self.view = view
        dataSource = ["Preferences": [(.csbPreferences, SBSettingsTVCViewModel(title: "Safe Box Storage"))]]
    }
}

extension SBSettingsInteractor: SBSettingsInteractorProtocol {
    func numberOfSections() -> Int {
        return dataSource.count
    }
    
    func numberOfRows(inSection section: Int) -> Int {
        return getSectionItems(for: section).count
    }
    
    func viewModel(forRowAt indexPath: IndexPath) -> SBSettingsTVCViewModel? {
        return getCurrentObject(for: indexPath)?.model
    }
    
    func titleForHeader(in section: Int) -> String {
        var index = 0
        for key in dataSource.keys {
            if index == section { return key }
            index += 1
        }
        return ""
    }
    
    func didSelect(rowAt indexPath: IndexPath) {
        
    }
    
    // MARK: - Helpers
    private func getSectionItems(for section: Int) -> Array<(segue: SBSettingsVCSegue, model: SBSettingsTVCViewModel)> {
        var index = 0
        var key: String?
        dataSource.keys.forEach { (k) in
            if index == section { key = k }
            index += 1
        }
        
        if key != nil, let sectionItems = dataSource[key!] {
            return sectionItems
        }
        return []
    }
    
    private func getCurrentObject(for indexPath: IndexPath) -> (segue: SBSettingsVCSegue, model: SBSettingsTVCViewModel)? {
        let sectionItems = getSectionItems(for: indexPath.section)
        guard sectionItems.indices.contains(indexPath.row) else { return nil }
        return sectionItems[indexPath.row]
    }
}
