//
//  SBNewCSBCollectionViewCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/17/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class SBNewCsbCvcViewModel {
    let imageName: String
    var isSelected: Bool
    
    init(imageName: String, isSelected: Bool) {
        self.imageName = imageName
        self.isSelected = isSelected
    }
}

class SBNewCSBCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var csbImageView: UIImageView!
    
    func setup(withModel model: SBNewCsbCvcViewModel?) {
        guard let model = model else { return }
        csbImageView.image = UIImage(named: model.imageName)
        contentView.backgroundColor = model.isSelected ? .highlight() : .white
    }
    
    static func reuseId() -> String {
        return "SBNewCSBCollectionViewCellReuseIdentifier"
    }
}
