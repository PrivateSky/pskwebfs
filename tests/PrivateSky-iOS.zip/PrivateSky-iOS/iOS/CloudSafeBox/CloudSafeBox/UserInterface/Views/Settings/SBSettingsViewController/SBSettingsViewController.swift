import UIKit

class SBSettingsViewController: UIViewController, SideMenuItemContent {

    var interactor: SBSettingsInteractorProtocol?
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBAction func showMenu(_ sender: Any) {
        showSideMenu()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        interactor = SBSettingsInteractor(withView: self)
    }
}

extension SBSettingsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return interactor?.numberOfSections() ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return interactor?.numberOfRows(inSection: section) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SBSettingsTableViewCell.reuseId(), for: indexPath) as! SBSettingsTableViewCell
        cell.setup(withModel: interactor?.viewModel(forRowAt: indexPath))
        return cell;
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return interactor?.titleForHeader(in: section)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        interactor?.didSelect(rowAt: indexPath)
    }
}
