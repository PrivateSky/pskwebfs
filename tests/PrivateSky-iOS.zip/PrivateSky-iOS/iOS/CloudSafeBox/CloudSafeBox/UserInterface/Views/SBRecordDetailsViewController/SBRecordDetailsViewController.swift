import UIKit

class SBRecordDetailsViewController: UIViewController {
    
    var interactor: SBRecordDetailsInteractorProtocol?
    private let minTableRowHeight: CGFloat = 75.0
    
    @IBOutlet weak var navBar: UIAppNavigationBar!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navBar.setup(with: getNavBarModel())
        setAppGradientBackground()
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.estimatedRowHeight = minTableRowHeight
        tableView.rowHeight = UITableViewAutomaticDimension
        interactor?.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navBar.backgroundColor = .clear
    }
    
    private func getNavBarModel() -> UIAppNavigationBarViewModel {
        return UIAppNavigationBarViewModel(title: interactor?.screenTitle() ?? "",
                                           isLeftButtonHidden: false,
                                           isRightButtonHidden: false,
                                           leftButtonImage: UIImage(named: "arrow_left"),
                                           rightButtonImage: UIImage(named: "edit_white"),
                                           onLeftButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.interactor?.dismiss()
            },
                                           onRightButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.interactor?.edit()
        })
    }
    
    func reloadData() {
        tableView.reloadData()
    }
    
    func setEditIcon(forState state: SBRecordDetailsVCState) {
        switch state {
        case .display:
            navBar.changeRightNavBarButtonImage(withImage: UIImage(named: "edit_white"))
        case .edit:
            navBar.changeRightNavBarButtonImage(withImage: UIImage(named: "tick"))
        case .new:
            navBar.changeRightNavBarButtonImage(withImage: UIImage(named: "tick"))
        }
    }
}

extension SBRecordDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return interactor?.numberOfSections() ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return interactor?.numberOfRows(inSection: section) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = interactor?.cell(forRowAt: indexPath, in: tableView) else {
            preconditionFailure("Unregistered table view cell")
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
}
