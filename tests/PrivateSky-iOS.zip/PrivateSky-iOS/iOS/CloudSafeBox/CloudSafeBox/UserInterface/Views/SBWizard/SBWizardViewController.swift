import UIKit

class SBWizardViewController: UIViewController {
    
    private var currentPageIndex = 0
    var interactor: SBWizardInteractorProtocol?

    @IBOutlet weak var swiftyOnboard: SwiftyOnboard!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        interactor = SBWizardInteractor(withView: self)
        swiftyOnboard.style = .light
        swiftyOnboard.delegate = self
        swiftyOnboard.dataSource = self
        swiftyOnboard.backgroundColor = UIColor.wizardBackground()
        view.backgroundColor = UIColor.wizardBackground()
    }
}

extension SBWizardViewController: SwiftyOnboardDelegate, SwiftyOnboardDataSource {
    func swiftyOnboardNumberOfPages(_ swiftyOnboard: SwiftyOnboard) -> Int {
        return interactor?.numberOfPages() ?? 0
    }
    
    func swiftyOnboardPageForIndex(_ swiftyOnboard: SwiftyOnboard, index: Int) -> SwiftyOnboardPage? {
        let viewModel = interactor?.viewModel(forPageAt: index)
        let view = SBRadioInputView(frame: self.view.frame)
        view.setup(with: viewModel)
        return view
    }
    
    func swiftyOnboardViewForOverlay(_ swiftyOnboard: SwiftyOnboard) -> SwiftyOnboardOverlay? {
        let overlay = SBWizardOverlayView.instanceFromNib() as? SBWizardOverlayView
        overlay?.setup(withModel: SBWizardOverlayViewViewModel(onSkip: { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.interactor?.finishWizard()
        }, onNext: { [weak self] in
            guard let strongSelf = self else { return }
            let pagesNo = strongSelf.interactor?.numberOfPages() ?? 0
            if strongSelf.currentPageIndex == pagesNo - 1 {
                strongSelf.interactor?.finishWizard()
            } else {
                strongSelf.currentPageIndex += 1
                strongSelf.swiftyOnboard.goToPage(index: strongSelf.currentPageIndex, animated: true)
            }
        }))
        return overlay
    }
    
    func swiftyOnboardOverlayForPosition(_ swiftyOnboard: SwiftyOnboard, overlay: SwiftyOnboardOverlay, for position: Double) {
        let sbOverlay = overlay as? SBWizardOverlayView
        sbOverlay?.contentControl.currentPage = swiftyOnboard.currentPage
        let pagesNo = interactor?.numberOfPages() ?? 0
        sbOverlay?.buttonContinue.setTitle(swiftyOnboard.currentPage == pagesNo - 1 ? "Get Started!" : "Continue", for: .normal)
    }
}
