import UIKit

class SBWizardVCCollectionViewCell: UICollectionViewCell {
    
    private let radioButtonHeight: CGFloat = 50.0
    private var viewModel: SBRadioInputViewViewModel?
    private var radioButtons = Array<SBRadioButtonView>()
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var stackViewHeightConstraint: NSLayoutConstraint!
    
    func setup(with viewModel: SBRadioInputViewViewModel?) {
        stackView.removeAllArrangedSubviews()
        radioButtons = Array<SBRadioButtonView>()
        guard let viewModel = viewModel else { return }
        self.viewModel = viewModel
        titleLabel.text = viewModel.title
        var index = 0
        viewModel.options.forEach { (option) in
            let radioButton = SBRadioButtonView(frame: CGRect(x: 0, y: 0, width: stackView.frame.width, height: radioButtonHeight))
            radioButton.update(with: SBRadioButtonViewModel(title: option, isSelected: viewModel.selectedOption == index, orderIndex: index, onSelection: { (selIndex) in
                guard let selIndex = selIndex else { return }
                self.viewModel!.selectedOption = selIndex
                self.updateRadioButtonsAndNotify()
            }))
            radioButtons.append(radioButton)
            index += 1
        }
        stackViewHeightConstraint.constant = CGFloat(radioButtons.count) * radioButtonHeight
        radioButtons.forEach { (button) in
            stackView.addArrangedSubview(button)
        }
    }
    
    func updateRadioButtonsAndNotify() {
        var index = 0
        radioButtons.forEach { (button) in
            button.update(isSelected: index == viewModel?.selectedOption)
            index += 1
        }
        guard let viewModel = viewModel else { return }
        viewModel.onOptionSelection(viewModel.selectedOption)
    }
    
    static func reuseId() -> String {
        return "SBWizardVCCollectionViewCellReuseIdentifier"
    }
}
