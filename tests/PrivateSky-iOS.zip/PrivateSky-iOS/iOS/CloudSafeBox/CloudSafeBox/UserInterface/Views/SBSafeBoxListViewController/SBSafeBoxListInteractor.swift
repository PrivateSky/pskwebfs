import CloudSafeBoxCore

protocol SBSafeBoxListInteractorProtocol {
    
    func navigationBarTitle() -> String
    func noContentMessage() -> String
    
    func viewDidAppear()
    func numberOfItemsInSection(_ section: Int) -> Int
    func modelForCellAt(indexPath: IndexPath) -> SBSafeBoxesCVCCellModel?
    func didSelectCellAt(indexPath: IndexPath)
    func addNewBox()
}

class SBSafeBoxListInteractor: NSObject {
    
    private var safeBoxes = [CloudSafeBox]() {
        didSet {
            safeBoxModels = provideCSBDataSource(from: safeBoxes)
        }
    }
    private weak var view: SBSafeBoxListViewController?
    private var router: SBSafeBoxListRouter?
    private var safeBoxModels = [SBSafeBoxesCVCCellModel]()
    
    init(view: SBSafeBoxListViewController?) {
        self.view = view
        self.router = SBSafeBoxListRouter(view: view)
        super.init()
    }
}

extension SBSafeBoxListInteractor: SBSafeBoxListInteractorProtocol {
    
    func navigationBarTitle() -> String {
        return "Cloud Safe Boxes"
    }
    
    func noContentMessage() -> String {
        return "There aren't any Cloud Safe Boxes available."
    }
    
    func viewDidAppear() {
        DependenciesManager.csbContainer().provideCSBList { [weak self] (csbList, error) in
            guard let strongSelf = self else { return }
            if let error = error {
                strongSelf.view?.showMessage(title: "Error", message: error.localizedDescription)
            } else {
                strongSelf.safeBoxes = csbList
                strongSelf.view?.reloadData(hasContent: csbList.count > 0)
            }
        }
    }
    
    func numberOfItemsInSection(_ section: Int) -> Int {
        return safeBoxModels.count
    }
    
    func modelForCellAt(indexPath: IndexPath) -> SBSafeBoxesCVCCellModel? {
        return safeBoxModels[indexPath.row]
    }
    
    func didSelectCellAt(indexPath: IndexPath) {
        let csb = safeBoxes[indexPath.row]
        router?.perform(segue: .csbDetail, withTransitionObject: csb)
    }
    
    func addNewBox() {
        guard let arrowFrame = view?.getAddButtonFrame() else { return }
        let viewModel = UIPopoverVCViewModel(items: ["Restore a CSB", "Create new CSB"],
                             cropFrame: arrowFrame) { [weak self] (index) in
                                guard let strongSelf = self else { return }
                                strongSelf.view?.dismissFromTop()
                                if index == 1 {
                                    strongSelf.router?.perform(segue: .newCSB, withTransitionObject: nil)
                                }
        }
        
        router?.perform(segue: .newCSBOptions, withTransitionObject: viewModel)
    }
}

extension SBSafeBoxListInteractor {
    
    private func provideCSBDataSource(from csbList: [CloudSafeBox]) -> [SBSafeBoxesCVCCellModel] {
        
        var result = [SBSafeBoxesCVCCellModel]()
        csbList.forEach { (csb) in
            result.append(SBSafeBoxesCVCCellModel(safeBoxImageName: csb.localImageName, title: csb.title))
        }
        return result
    }
}
