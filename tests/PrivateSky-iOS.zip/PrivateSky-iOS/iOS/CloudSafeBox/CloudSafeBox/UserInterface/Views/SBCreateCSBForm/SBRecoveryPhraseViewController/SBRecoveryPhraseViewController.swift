//
//  SBRecoveryPhraseViewController.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/17/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class SBRecoveryPhraseViewController: UIViewController {
    
    var interactor: SBRecoveryPhraseInteractor?

    @IBOutlet weak var navBar: UIAppNavigationBar!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var instructionsLabel: UILabel!
    @IBOutlet weak var warningLabel: UILabel!
    @IBOutlet weak var recoveryPhraseLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    
    @IBAction func didTapNextButton(_ sender: Any) {
        interactor?.didTapNextButton()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navBar.setup(with: getNavBarModel())
        setAppGradientBackground()
        nextButton.backgroundColor = UIColor.strongHighlight()
        interactor?.provideRecoveryPhrase { [weak self] seed in
            self?.recoveryPhraseLabel.text = seed
        }
        recoveryPhraseLabel.textColor = .mainText()
        titleLabel.textColor = .mainText()
        instructionsLabel.textColor = .generalText()
        warningLabel.textColor = .warning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = kNewCSBFormTitle
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationItem.title = ""
    }
    
    private func getNavBarModel() -> UIAppNavigationBarViewModel {
        return UIAppNavigationBarViewModel(title: interactor?.screenTitle() ?? "",
                                           isLeftButtonHidden: false,
                                           isRightButtonHidden: true,
                                           leftButtonImage: UIImage(named: "arrow_left"),
                                           rightButtonImage: nil,
                                           onLeftButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.navigationController?.popViewController(animated: true)
            },
                                           onRightButtonTap: nil)
    }
}
