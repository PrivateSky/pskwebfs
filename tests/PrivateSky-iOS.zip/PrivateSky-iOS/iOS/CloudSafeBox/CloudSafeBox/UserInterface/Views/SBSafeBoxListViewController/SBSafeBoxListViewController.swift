//
//  SBSafeBoxesViewController.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 3/28/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

protocol SBSafeBoxListVCDelegate {
    func reloadData(hasContent: Bool)
    func getAddButtonFrame() -> CGRect
}

class SBSafeBoxListViewController: UIViewController, SideMenuItemContent {
    
    fileprivate let sectionPadding: CGFloat = 16;
    fileprivate let itemSpacing: CGFloat = 8;
    private var interactor: SBSafeBoxListInteractor?

    @IBOutlet weak var navBar: UIAppNavigationBar!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var noContentView: UINoContentView!
    @IBOutlet weak var addButton: UIButton!
    
    @IBAction func didTapLeftBarButtonItem(_ sender: Any) {
        showSideMenu()
    }
    
    @IBAction func addNewBox(_ sender: Any) {
        interactor?.addNewBox()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        interactor = SBSafeBoxListInteractor(view: self)
        navigationController?.setNavigationBarHidden(true, animated: false)
        navBar.setup(with: getNavBarModel())
        setAppGradientBackground()
        noContentView.setup(withTitle: interactor?.noContentMessage() ?? "")
        addButton.backgroundColor = .strongHighlight()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        interactor?.viewDidAppear()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationItem.title = ""
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { [weak self] (context) in
            self?.collectionView.collectionViewLayout.invalidateLayout()
        }, completion: nil)
    }
    
    private func getNavBarModel() -> UIAppNavigationBarViewModel {
        return UIAppNavigationBarViewModel(title: interactor?.navigationBarTitle() ?? "",
                                           isLeftButtonHidden: false,
                                           isRightButtonHidden: true,
                                           leftButtonImage: UIImage(named: "hamburger_icon"),
                                           rightButtonImage: nil,
                                           onLeftButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.showSideMenu()
                                           },
                                           onRightButtonTap: nil)
    }
}
    
extension SBSafeBoxListViewController: SBSafeBoxListVCDelegate {
    
    func reloadData(hasContent: Bool) {
        collectionView.isHidden = !hasContent
        noContentView.isHidden = hasContent
        if hasContent {
            collectionView.reloadData()
        }
    }
    
    func getAddButtonFrame() -> CGRect {
        return addButton.frame
    }
}

extension SBSafeBoxListViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return interactor?.numberOfItemsInSection(section) ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SBSafeBoxListCollectionViewCell.reuseId(), for: indexPath) as! SBSafeBoxListCollectionViewCell
        cell.setup(with: interactor?.modelForCellAt(indexPath: indexPath))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        interactor?.didSelectCellAt(indexPath: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize
    {
        return self.cellSize(viewWidth: collectionView.frame.size.width, isDeviceInLandscape: SBCommonUtilities.isDeviceInLandscape);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        return UIEdgeInsets(top: sectionPadding, left: sectionPadding, bottom: sectionPadding, right: sectionPadding);
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat
    {
        return self.itemSpacing
    }
    
    // MARK: - Helper Methods
    private func cellSize(viewWidth width: CGFloat, isDeviceInLandscape: Bool) -> CGSize {
        var numOfItemsPerRow: CGFloat = 2
        if isDeviceInLandscape {
            numOfItemsPerRow += 1
        }
        
        let occupiedWidth = 2 * sectionPadding + (numOfItemsPerRow * itemSpacing)
        let availableWidth = width - occupiedWidth
        let size = (availableWidth / numOfItemsPerRow)
        
        let result =  CGSize(width: round(size), height: round(size));
        return result
    }
}
