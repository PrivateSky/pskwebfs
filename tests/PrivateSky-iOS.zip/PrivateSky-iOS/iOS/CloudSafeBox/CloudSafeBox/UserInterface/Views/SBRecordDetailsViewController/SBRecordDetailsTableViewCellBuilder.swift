import UIKit

class SBRecordDetailsTableViewCellBuilder {

//    static func buildCells() -> UITableViewCell {
//        
//    }
    
}
