//
//  SBSafeBoxItemTableViewCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 6/4/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class SBSafeBoxItemTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        titleLabel.textColor = .generalText()
    }
    
    func setup(withTitle title: String) {
        titleLabel.text = title
    }

    static func reuseId() -> String {
        return "SBSafeBoxItemTableViewCellReuseIdentifier"
    }
}
