import UIKit
import CloudSafeBoxCore

protocol SBRecoveryPhraseInteractorProtocol {
    func screenTitle() -> String
    func provideRecoveryPhrase(completion: (_ seed: String) -> Void) 
    func didTapNextButton()
}

class SBRecoveryPhraseInteractor {
    
    private weak var view: SBRecoveryPhraseViewController?
    private var csbCreationSession: INewCSBSession
    private var recoveryPhrase: String
    
    init(view: SBRecoveryPhraseViewController?, csbCreationSession: INewCSBSession) {
        self.view = view
        self.recoveryPhrase = ""
        self.csbCreationSession = csbCreationSession
    }
}

extension SBRecoveryPhraseInteractor: SBRecoveryPhraseInteractorProtocol {
    
    func screenTitle() -> String {
        return "Recovery Phrase"
    }
    
    func provideRecoveryPhrase(completion: (_ seed: String) -> Void) {
        csbCreationSession.addRecoveryPhrase { (seed) in
            completion(seed)
        }
    }
    
    func didTapNextButton() {
        csbCreationSession.submit { [weak self] (success, error) in
            guard let strongSelf = self else { return }
            if success {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "ana") , object: nil)
            } else if let errorDescription = error?.localizedDescription {
                strongSelf.view?.showMessage(title: "Error", message: errorDescription)
            }
        }
    }
}
