import CloudSafeBoxCore

enum SBSafeBoxDetailsVCSegue {
    case itemDetails
    case newRecordOptions
    case newRecord
}

class SBSafeBoxDetailsRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController?) {
        self.view = view
    }
    
    func perform(segue: SBSafeBoxDetailsVCSegue, withTransitionObject object: Any?) {
        switch segue {
        case .itemDetails, .newRecord:
            if let object = object as? SBRecordDetailsVCViewModel {
                let vc = SBControllersContainer.recordDetailsViewController
                let interactor = SBRecordDetailsInteractor(view: vc, viewModel: object, state: recordDetailsState(from: segue))
                vc.interactor = interactor
                view?.navigationController?.pushViewController(vc, animated: true)
            }
        case .newRecordOptions:
            let vc = SBControllersContainer.popoverViewController
            vc.modalPresentationStyle = .overCurrentContext
            if let object = object as? UIPopoverVCViewModel {
                vc.setup(with: object)
            }
            view?.navigationController?.present(vc, animated: false, completion: nil)
        }
    }
    
    private func recordDetailsState(from segue: SBSafeBoxDetailsVCSegue) -> SBRecordDetailsVCState {
        return segue == .newRecord ? .new : .display
    }
}
