//
//  SBNewCSBViewController.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/17/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

let kNewCSBFormTitle = "New Cloud Safe Box"

protocol SBNewCSBViewControllerProtocol {
    func reloadData()
}

class SBNewCSBViewController: UIViewController {

    var interactor: SBNewCSBInteractor?
    
    @IBOutlet weak var navBar: UIAppNavigationBar!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var nextButton: UIButton!
    
    @IBAction func didTapNextButton(_ sender: Any) {
        interactor?.didTapNextButton(withTitle: titleTextField.text)
    }
    
    @objc func didReceivedNewCSBFormSubmitNotification() {
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupControls()
        NotificationCenter.default.addObserver(self, selector: #selector(didReceivedNewCSBFormSubmitNotification), name: NSNotification.Name("ana"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.title = kNewCSBFormTitle
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationItem.title = ""
    }
    
    // MARK: - Private Methods
    private func setupControls() {
        navBar.setup(with: getNavBarModel())
        setAppGradientBackground()
        collectionView.delegate = self
        collectionView.dataSource = self
        titleTextField.delegate = self
        changeNextButtonState(enabled: false)
        titleTextField.textColor = .mainText()
    }
    
    private func changeNextButtonState(enabled: Bool) {
        if enabled {
            nextButton.isUserInteractionEnabled = true
            nextButton.backgroundColor = UIColor.strongHighlight()
        } else {
            nextButton.backgroundColor = UIColor.inactiveControl()
            nextButton.isUserInteractionEnabled = false
        }
    }
    
    private func getNavBarModel() -> UIAppNavigationBarViewModel {
        return UIAppNavigationBarViewModel(title: interactor?.screenTitle() ?? "",
                                           isLeftButtonHidden: false,
                                           isRightButtonHidden: true,
                                           leftButtonImage: UIImage(named: "arrow_left"),
                                           rightButtonImage: nil,
                                           onLeftButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.navigationController?.popViewController(animated: true)
            },
                                           onRightButtonTap: nil)
    }
}

extension SBNewCSBViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return interactor?.numberOfItemsInCollectionView() ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SBNewCSBCollectionViewCell.reuseId(), for: indexPath) as! SBNewCSBCollectionViewCell
        cell.setup(withModel: interactor?.viewModel(forCellAt: indexPath))
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        interactor?.didSelect(cellAt: indexPath)
    }
}

extension SBNewCSBViewController: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let newText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        
        changeNextButtonState(enabled: interactor?.shouldEnableNextButton(forTitle: newText) ?? false)
        
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension SBNewCSBViewController: SBNewCSBViewControllerProtocol {
    
    func reloadData() {
        collectionView.reloadData()
    }
}
