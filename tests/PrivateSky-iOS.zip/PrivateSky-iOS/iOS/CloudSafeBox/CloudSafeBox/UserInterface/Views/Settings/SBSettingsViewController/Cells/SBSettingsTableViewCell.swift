import UIKit

struct SBSettingsTVCViewModel {
    let title: String
}

class SBSettingsTableViewCell: UITableViewCell {

    var model: SBSettingsTVCViewModel?
    
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    func setup(withModel model: SBSettingsTVCViewModel?) {
        guard let model = model else { return }
        titleLabel.text = model.title
    }
    
    static func reuseId() -> String {
        return "SBSettingsTableViewCellReuseIdentifier"
    }
}
