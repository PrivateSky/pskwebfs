import UIKit

struct SBRecordDetailsTextTVCViewModel {
    let sectionName: String
    let content: String?
    let onContentChange: ((_ newContent: String) -> Void)?
}

class SBRecordDetailsTextTableViewCell: UITableViewCell {
    
    private var viewModel: SBRecordDetailsTextTVCViewModel?
    
    @IBOutlet weak var sectionNameLabel: UILabel!
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var textViewHeightConstraint: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        addCustomSeparatorView()
        textView.delegate = self
        sectionNameLabel.textColor = .generalText()
        textView.textColor = .mainText()
    }
    
    func setup(with viewModel: SBRecordDetailsTextTVCViewModel?) {
        guard let viewModel = viewModel else { return }
        self.viewModel = viewModel
        sectionNameLabel.text = viewModel.sectionName
        textView.text = viewModel.content ?? ""
        let sizeThatFitsContent = textView.sizeThatFits(textView.frame.size)
        textViewHeightConstraint.constant = sizeThatFitsContent.height
    }
    
    static func reuseId() -> String {
        return "SBRecordDetailsTextTableViewCellReuseIdentifier"
    }
}

extension SBRecordDetailsTextTableViewCell: UITextViewDelegate {
    
    func textViewDidChange(_ textView: UITextView) {
        viewModel?.onContentChange?(textView.text)
    }
}
