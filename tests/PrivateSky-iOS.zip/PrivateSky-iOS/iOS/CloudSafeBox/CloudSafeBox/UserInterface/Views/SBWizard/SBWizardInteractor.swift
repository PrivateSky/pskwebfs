import UIKit
import CloudSafeBoxCore

protocol SBWizardInteractorProtocol {
    func numberOfPages() -> Int
    func viewModel(forPageAt index: Int) -> SBRadioInputViewViewModel
    func finishWizard()
}

class SBWizardInteractor {
    
    private weak var view: SBWizardViewController?
    private var router: SBWizardRouter
    private var wizard: Wizard
    
    init(withView view: SBWizardViewController) {
        self.view = view
        self.router = SBWizardRouter(view: view)
        self.wizard = Wizard()
    }
}

extension SBWizardInteractor: SBWizardInteractorProtocol {
    
    func numberOfPages() -> Int {
        return wizard.questions.count
    }
    
    func viewModel(forPageAt index: Int) -> SBRadioInputViewViewModel {
        let currentQuestion = wizard.questions[index]
        return SBRadioInputViewViewModel(title: currentQuestion.question, options: currentQuestion.answers, selectedOption: currentQuestion.correctIndex, onOptionSelection: { (i) in
            self.wizard.questions[index].correctIndex = i
        })
    }
    
    func finishWizard() {
        wizard.submit()
        UserDefaults.setSynchronizedBool(value: true, forKey: SBUserDefaultsKeys.didCompleteWizard.rawValue)
        router.perform(segue: .csbList, withTransitionObject: nil)
    }
}
