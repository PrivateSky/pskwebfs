import CloudSafeBoxCore

protocol SBNewCSBInteractorProtocol {
    
    func screenTitle() -> String
     
    func numberOfItemsInCollectionView() -> Int
    func viewModel(forCellAt indexPath: IndexPath) -> SBNewCsbCvcViewModel
    func didSelect(cellAt indexPath: IndexPath)
    
    func didTapNextButton(withTitle title: String?)
    func shouldEnableNextButton(forTitle title: String) -> Bool
}

class SBNewCSBInteractor {
    
    private weak var view: SBNewCSBViewController?
    private var router: SBNewCSBRouter?
    private var csbImageNameList: [SBNewCsbCvcViewModel] = []
    private var csbCreationSession: INewCSBSession
    
    init(view: SBNewCSBViewController?) {
        self.view = view
        self.router = SBNewCSBRouter(view: view)
        self.csbCreationSession = DependenciesManager.newCSBForm()
        self.csbImageNameList = provideDefaultCSBImageNameList()
    }
}

extension SBNewCSBInteractor: SBNewCSBInteractorProtocol {
    
    func screenTitle() -> String {
        return "Basic Information"
    }
    
    func numberOfItemsInCollectionView() -> Int {
        return csbImageNameList.count
    }
    
    func viewModel(forCellAt indexPath: IndexPath) -> SBNewCsbCvcViewModel {
        return csbImageNameList[indexPath.row]
    }
    
    func didSelect(cellAt indexPath: IndexPath) {
        var index = 0
        for model in csbImageNameList {
            if index == indexPath.row {
                model.isSelected = true
            } else {
                model.isSelected = false
            }
            index += 1
        }
        view?.reloadData()
    }
    
    func didTapNextButton(withTitle title: String?) {
        guard let title = title else { return }
        
        csbCreationSession.add(title: title, imageName: csbImageNameList.filter({ (model) -> Bool in return model.isSelected }).first?.imageName ?? "")
        
        router?.perform(segue: .recoveryPhrase, withTransitionObject: csbCreationSession)
    }
    
    func shouldEnableNextButton(forTitle title: String) -> Bool {
        return title.count > 0
    }
}

private extension SBNewCSBInteractor {
    
    private func provideDefaultCSBImageNameList() -> [SBNewCsbCvcViewModel] {
        return [SBNewCsbCvcViewModel(imageName: "csbicon01", isSelected: true),
                SBNewCsbCvcViewModel(imageName: "csbicon02", isSelected: false),
                SBNewCsbCvcViewModel(imageName: "csbicon03", isSelected: false),
                SBNewCsbCvcViewModel(imageName: "csbicon04", isSelected: false),
                SBNewCsbCvcViewModel(imageName: "csbicon05", isSelected: false),
                SBNewCsbCvcViewModel(imageName: "csbicon06", isSelected: false),
                SBNewCsbCvcViewModel(imageName: "csbicon07", isSelected: false)]
    }
}
