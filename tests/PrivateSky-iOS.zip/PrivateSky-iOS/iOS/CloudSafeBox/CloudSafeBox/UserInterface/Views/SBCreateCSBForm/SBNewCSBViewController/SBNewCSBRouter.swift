import CloudSafeBoxCore

enum SBNewCSBSegue {
    case recoveryPhrase
}

class SBNewCSBRouter: NSObject {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController?) {
        self.view = view
    }
    
    func perform(segue: SBNewCSBSegue, withTransitionObject object: Any) {
        
        switch segue {
        case .recoveryPhrase:
            if let csbCreationSession = object as? INewCSBSession {
                let vc = SBControllersContainer.recoveryPhraseViewController
                let interactor = SBRecoveryPhraseInteractor(view: vc, csbCreationSession: csbCreationSession)
                vc.interactor = interactor
                view?.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
