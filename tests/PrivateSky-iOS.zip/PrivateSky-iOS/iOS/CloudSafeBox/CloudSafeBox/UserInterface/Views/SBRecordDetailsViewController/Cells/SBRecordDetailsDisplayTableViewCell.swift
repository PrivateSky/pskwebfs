import UIKit

struct SBRecordDetailsDisplayTVCViewModel {
    let sectionName: String
    let content: String?
}

class SBRecordDetailsDisplayTableViewCell: UITableViewCell {

    @IBOutlet weak var sectionNameLabel: UILabel!
    @IBOutlet weak var contentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.addCustomSeparatorView()
        sectionNameLabel.textColor = .generalText()
        contentLabel.textColor = .mainText()
    }
    
    func setup(with viewModel: SBRecordDetailsDisplayTVCViewModel?) {
        guard let viewModel = viewModel else { return }
        sectionNameLabel.text = viewModel.sectionName
        contentLabel.text = viewModel.content
    }
    
    static func reuseId() -> String {
        return "SBGenericListTableViewCellReuseIdentifier"
    }
}
