import UIKit
import CloudSafeBoxCore

enum SBSafeBoxesVCSegue {
    case csbDetail
    case newCSBOptions
    case newCSB
}

class SBSafeBoxListRouter {
    
    private weak var view: UIViewController?
    
    init(view: UIViewController?) {
        self.view = view
    }
    
    func perform(segue: SBSafeBoxesVCSegue, withTransitionObject object: Any?) {
        switch segue {
        case .csbDetail:
            if let object = object as? CloudSafeBox {
                let vc = SBControllersContainer.safeBoxDetailsViewController
                let interactor = SBSafeBoxDetailsInteractor(view: vc, cloudSafeBox: object)
                vc.interactor = interactor
                view?.navigationController?.pushViewController(vc, animated: true)
            }
        case .newCSBOptions:
            let vc = SBControllersContainer.popoverViewController
            vc.modalPresentationStyle = .overCurrentContext
            if let object = object as? UIPopoverVCViewModel {
                vc.setup(with: object)
            }
            view?.navigationController?.present(vc, animated: false, completion: nil)
        case .newCSB:
            let vc = SBControllersContainer.newCSBViewController
            let interactor = SBNewCSBInteractor(view: vc)
            vc.interactor = interactor
            view?.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
