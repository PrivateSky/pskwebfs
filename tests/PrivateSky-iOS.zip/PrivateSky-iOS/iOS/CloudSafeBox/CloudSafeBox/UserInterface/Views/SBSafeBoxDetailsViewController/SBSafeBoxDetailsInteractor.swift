import UIKit
import CloudSafeBoxCore

class SBSafeBoxDetailsVCModel {
    let title: String
    let image: UIImage?
    var isExpanded = false
    var records = [String]()
    
    init(title: String, image: UIImage?) {
        self.title = title
        self.image = image
    }
}

protocol SBSafeBoxDetailsVCInteractorProtocol {
    
    func screenTitle() -> String
    func noContentMessage() -> String
    
    func viewDidLoad()
    func addNewRecord()
    
    func numberOfSections() -> Int
    func numberOfRows(inSection section: Int) -> Int
    func title(forRowAt indexPath: IndexPath) -> String
    func didSelect(rowAt indexPath: IndexPath)
    
    func model(forSectionAt index: Int) -> UISectionHeaderViewModel
    func didSelect(sectionAt index: Int)
    
    func editActionsModel(forRowAt indexPath: IndexPath) -> [(title: String, color: UIColor, completion: () -> ())]
}

class SBSafeBoxDetailsInteractor: NSObject {
    
    private weak var view: SBSafeBoxDetailsViewController?
    private var router: SBSafeBoxDetailsRouter
    private var cloudSafeBox: CloudSafeBox
    
    private var categoriesDataSource = [SBSafeBoxDetailsVCModel]()
    
    init(view: SBSafeBoxDetailsViewController?, cloudSafeBox: CloudSafeBox) {
        self.view = view
        self.cloudSafeBox = cloudSafeBox
        self.router = SBSafeBoxDetailsRouter(view: view)
        super.init()
        buildDataSource()
    }
    
    func buildDataSource() {
        categoriesDataSource = []
        cloudSafeBox.data.forEach { (category) in
            let titles = category.records.map({ (dict) -> String? in return dict["Title"] as? String }).compactMap { $0 }
            if titles.count == 0 { return }
            let item = SBSafeBoxDetailsVCModel(title: category.title, image: DependenciesManager.csbRecordsHandler().image(forCategoryName: category.title))
            item.records = titles
            categoriesDataSource.append(item)
        }
    }
    
    private func reloadData() {
        buildDataSource()
        view?.reloadData(hasContent: categoriesDataSource.count > 0)
    }
}

extension SBSafeBoxDetailsInteractor: SBSafeBoxDetailsVCInteractorProtocol {
    
    func viewDidLoad() {
        view?.reloadData(hasContent: categoriesDataSource.count > 0)
    }
    
    func addNewRecord() {
        let recordStructures = DependenciesManager.csbRecordsHandler().getDefinedRecordStructures()
        let newRecordOptionsModel = UIPopoverVCViewModel(items: recordStructures.map {$0.categoryName}, cropFrame: view?.getAddButtonFrame() ?? .zero) { [weak self] (index) in
            guard let strongSelf = self else { return }
            strongSelf.view?.dismissFromTop()
            let newRecordViewModel = strongSelf.newRecordViewModel(forRecordStructure: recordStructures[index], completion: { (fields) in
                strongSelf.cloudSafeBox.addRecord(forCategory: recordStructures[index].categoryName, fields: fields)
                strongSelf.reloadData()
            })
            strongSelf.router.perform(segue: .newRecord, withTransitionObject: newRecordViewModel)
        }
        router.perform(segue: .newRecordOptions, withTransitionObject: newRecordOptionsModel)
    }
    
    func screenTitle() -> String {
        return cloudSafeBox.title
    }
    
    func noContentMessage() -> String {
        return "No records available"
    }
    
    func numberOfSections() -> Int {
        return categoriesDataSource.count
    }
    
    func numberOfRows(inSection section: Int) -> Int {
        guard categoriesDataSource[section].isExpanded else { return 0 }
        return categoriesDataSource[section].records.count
    }
    
    func title(forRowAt indexPath: IndexPath) -> String {
        return categoriesDataSource[indexPath.section].records[indexPath.row]
    }
    
    func didSelect(rowAt indexPath: IndexPath) {
        let csbDS = categoriesDataSource[indexPath.section]
        guard let currentCategoryItems = cloudSafeBox.categoryRecords(byTitle: csbDS.title),
            let recordStructure = DependenciesManager.csbRecordsHandler().recordStructure(forCategoryName: csbDS.title) else { return }
        
        let currentItem = currentCategoryItems[indexPath.row]
        var model = SBRecordDetailsVCViewModel(title: csbDS.records[indexPath.row], fields: []) { [weak self] (newValues) in
            self?.cloudSafeBox.updateRecord(forCategory: csbDS.title, fields: newValues)
        }
        currentItem.keys.forEach { (key) in
            if let value = currentItem[key] as? String, let val = value.data(using: String.Encoding.utf8) {
                model.fields.append((key, val, recordStructure.dataType(forField: key)))
            }
        }
        
        router.perform(segue: .itemDetails, withTransitionObject: model)
    }
    
    func model(forSectionAt index: Int) -> UISectionHeaderViewModel {
        let model = categoriesDataSource[index]
        return UISectionHeaderViewModel(title: model.title, image: model.image, isExpanded: model.isExpanded, onSectionSelection: { [weak self] in
            self?.didSelect(sectionAt: index)
        })
    }
    
    func didSelect(sectionAt index: Int) {
        var i = 0
        categoriesDataSource.forEach { (model) in
            if i == index {
                model.isExpanded = !model.isExpanded
            } else {
                model.isExpanded = false
            }
            i += 1
        }
        view?.reloadData(hasContent: true, tableViewSection: index)
    }
    
    func editActionsModel(forRowAt indexPath: IndexPath) -> [(title: String, color: UIColor, completion: () -> ())] {
        return [("Delete", .warning(), { [weak self] in
            guard let strongSelf = self else { return }
            let model = strongSelf.categoriesDataSource[indexPath.section]
            strongSelf.cloudSafeBox.deleteRecord(forCategory: model.title, at: indexPath.row)
            strongSelf.reloadData()
        })]
    }
    
    private func newRecordViewModel(forRecordStructure recStructure: CSBRecordStructure, completion: @escaping (_ updatedFields: [(key: String, value: Data, dataType: CSBRecordDataType)]) -> Void) -> SBRecordDetailsVCViewModel {
        var record = SBRecordDetailsVCViewModel(title: "New Record", fields: [], completion: completion)
        
        recStructure.fields.forEach { (field) in
            record.fields.append((field.name, Data(), field.dataType))
        }
        
        return record
    }
}
