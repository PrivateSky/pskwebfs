//
//  SBSafeBoxesCVCCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 3/28/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct SBSafeBoxesCVCCellModel {
    var safeBoxImageName: String?
    var title: String
}

class SBSafeBoxListCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var safeBoxImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        titleLabel.textColor = .mainText()
        contentView.backgroundColor = .listItemBackground()
    }
    
    static func reuseId() -> String {
        return "SBSafeBoxListCollectionViewCellReuseIdentifier"
    }
    
    func setup(with model: SBSafeBoxesCVCCellModel?) {
        addShadow()
        guard let model = model else { return }
        titleLabel.text = model.title
        if let imageName = model.safeBoxImageName {
            safeBoxImageView.image = UIImage(named: imageName)
        }
    }
}
