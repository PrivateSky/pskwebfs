import UIKit

struct SBRecordDetailsDocTVCViewModel {
    let sectionName: String
    let document: Data
}

class SBRecordDetailsDocTableViewCell: UITableViewCell {
    
    @IBOutlet weak var sectionNameLabel: UILabel!

    @IBAction func addDocument(_ sender: Any) {
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        addCustomSeparatorView()
        sectionNameLabel.textColor = .generalText()
    }
    
    static func reuseId() -> String {
        return "SBRecordDetailsDocTableViewCellReuseIdentifier"
    }
}
