import UIKit

class SBSafeBoxDetailsViewController: UIViewController {

    private let minTableRowHeight: CGFloat = 50
    var interactor: SBSafeBoxDetailsVCInteractorProtocol?
    
    @IBOutlet weak var navBar: UIAppNavigationBar!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var noContentView: UINoContentView!
    @IBOutlet weak var addButton: UIButton!
    
    @IBAction func addNewRecord(_ sender: Any) {
        interactor?.addNewRecord()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navBar.setup(with: getNavBarModel())
        noContentView.setup(withTitle: interactor?.noContentMessage() ?? "")
        setAppGradientBackground()
        addButton.backgroundColor = .strongHighlight()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.estimatedRowHeight = minTableRowHeight
        tableView.rowHeight = UITableViewAutomaticDimension
        
        interactor?.viewDidLoad()
    }
    
    private func getNavBarModel() -> UIAppNavigationBarViewModel {
        return UIAppNavigationBarViewModel(title: interactor?.screenTitle() ?? "",
                                           isLeftButtonHidden: false,
                                           isRightButtonHidden: true,
                                           leftButtonImage: UIImage(named: "arrow_left"),
                                           rightButtonImage: nil,
                                           onLeftButtonTap: { [weak self] in
                                            guard let strongSelf = self else { return }
                                            strongSelf.navigationController?.popViewController(animated: true)
            },
                                           onRightButtonTap: nil)
    }
    
    func reloadData(hasContent: Bool, tableViewSection: Int? = nil) {
        tableView.isHidden = !hasContent
        noContentView.isHidden = hasContent
        tableView.reloadData()
        if let tableViewSection = tableViewSection {
            tableView.reloadSections(IndexSet(integer: tableViewSection) , with: .fade)
        }
    }
    
    func getAddButtonFrame() -> CGRect {
        return addButton.frame
    }
}

extension SBSafeBoxDetailsViewController: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let vw = UISectionHeaderView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 75.0))
        vw.setup(with: interactor?.model(forSectionAt: section))
        return vw
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 75.0
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let vw = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 0.5))
        vw.backgroundColor = .separatorColor()
        return vw
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.5
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return interactor?.numberOfSections() ?? 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return interactor?.numberOfRows(inSection: section) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: SBSafeBoxItemTableViewCell.reuseId(), for: indexPath) as! SBSafeBoxItemTableViewCell
        cell.setup(withTitle: interactor?.title(forRowAt: indexPath) ?? "")
        return cell;
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        interactor?.didSelect(rowAt: indexPath)
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        guard let actionsModels = interactor?.editActionsModel(forRowAt: indexPath) else { return nil }
        var actions = [UITableViewRowAction]()
        actionsModels.forEach { (model) in
            let action = UITableViewRowAction(style: .normal, title: model.title, handler: { (action, index) in
                model.completion()
            })
            action.backgroundColor = model.color
            actions.append(action)
        }
        return actions
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
}
