//
//  SBSafeBoxItemCategoryCollectionViewCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 6/4/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct SBSafeBoxItemCategoryCVCViewModel {
    let title: String
    var isFocused: Bool
}

class SBSafeBoxItemCategoryCollectionViewCell: UICollectionViewCell {
    
    private var model: SBSafeBoxItemCategoryCVCViewModel?
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var focusView: UIView!
    
    func setup(withModel model: SBSafeBoxItemCategoryCVCViewModel?) {
        guard let model = model else { return }
        self.model = model
        titleLabel.text = model.title
        focusView.backgroundColor = model.isFocused ? .highlight() : .clear
        titleLabel.textColor = model.isFocused ? .highlight() : .mainText()
    }
    
    static func reuseId() -> String {
        return "SBSafeBoxItemCategoryCollectionViewCellReuseIdentifier"
    }
}
