//
//  SBAlertViewController.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/27/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class SBAlertViewController: NSObject {
    
    static func presentOkAlert(from viewController: UIViewController, title: String, message: String) {
        presentOkAlert(from: viewController, title: title, message: message, submitCallback: nil)
    }
    
    static func presentOkAlert(from viewController: UIViewController, title: String, message: String, submitCallback: ((UIAlertAction) -> Void)?) {
        presentOptionsAlert(from: viewController, title: title, message: message, actions: [(title: "Ok", callback: submitCallback)])
    }
    
    static func presentOkCancelAlert(from viewController: UIViewController, title: String, message: String, submitCallback: ((UIAlertAction) -> Void)?, cancelCallback: ((UIAlertAction) -> Void)?) {
        presentOptionsAlert(from: viewController, title: title, message: message, actions: [(title: "Cancel", callback: cancelCallback), (title: "Ok", callback: submitCallback)])
    }
    
    static func presentOptionsAlert(from viewController: UIViewController, title: String, message: String, actions: [(title: String, callback: ((UIAlertAction) -> Void)?)]) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for action in actions {
            alert.addAction(UIAlertAction(title: action.title, style: .default, handler: action.callback))
        }
        viewController.present(alert, animated: true, completion: nil)
    }
}
