import UIKit

class SBControllersContainer: NSObject {
    
    private static let main = UIStoryboard(name: "Main", bundle: nil)
    private static let form = UIStoryboard(name: "Form", bundle: nil)
    private static let settings = UIStoryboard(name: "Settings", bundle: nil)
    
    static var safeBoxListViewController: SBSafeBoxListViewController {
        return main.instantiateViewController(withIdentifier: "SBSafeBoxListViewControllerStoryboardId") as! SBSafeBoxListViewController
    }
    
    static var safeBoxListNavigationController: UINavigationController {
        return UINavigationController(rootViewController: safeBoxListViewController)
        //return main.instantiateViewController(withIdentifier: "SBSafeBoxListNavigationControllerStoryboardId") as! UINavigationController
    }
    
    static var safeBoxDetailsViewController: SBSafeBoxDetailsViewController {
        return main.instantiateViewController(withIdentifier: "SBSafeBoxDetailsViewControllerStoryboardId") as! SBSafeBoxDetailsViewController
    }
    
    static var newCSBViewController: SBNewCSBViewController {
        return form.instantiateViewController(withIdentifier: "SBNewCSBViewControllerStoryboardId") as! SBNewCSBViewController
    }
    
    static var recoveryPhraseViewController: SBRecoveryPhraseViewController {
        return form.instantiateViewController(withIdentifier: "SBRecoveryPhraseViewControllerStoryboardId") as! SBRecoveryPhraseViewController
    }
    
    static var recordDetailsViewController: SBRecordDetailsViewController {
        return main.instantiateViewController(withIdentifier: "SBGenericListViewControllerStoryboardId") as! SBRecordDetailsViewController
    }
    
    static var wizardViewController: SBWizardViewController {
        return settings.instantiateViewController(withIdentifier: "SBWizardViewControllerStoryboardId") as! SBWizardViewController
    }
    
    static var popoverViewController: UIPopoverViewController {
        return UIPopoverViewController(nibName: "UIPopoverViewController", bundle: nil)
    }
    
    // MARK: - Settings
    static var settingsNavigationController: UINavigationController {
        return settings.instantiateViewController(withIdentifier: "SBSettingsNavigationControllerStoryboardId") as! UINavigationController
    }
    
    // MARK: - Menu
    static var sideMenuViewController: SBSideMenuViewController {
        return settings.instantiateViewController(withIdentifier: "SBSideMenuViewControllerStoryboardId") as! SBSideMenuViewController
    }
    
    static var menuHostViewController: SBMenuHostViewController {
        return settings.instantiateViewController(withIdentifier: "SBHostViewControllerStoryboardId") as! SBMenuHostViewController
    }
    
    // MARK: - Public Methods
    static func launch(with window: UIWindow?) {
        if UserDefaults.boolForKey(forKey: SBUserDefaultsKeys.didCompleteWizard.rawValue) {
            window?.rootViewController = menuHostViewController
        } else {
            window?.rootViewController = wizardViewController
        }
    }
}
