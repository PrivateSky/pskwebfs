//
//  SBCommonUtilities.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 3/28/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class SBCommonUtilities: NSObject {

    static var isDeviceInLandscape: Bool {
        let screen = UIScreen.main;
        return screen.bounds.width > screen.bounds.height
    }
}
