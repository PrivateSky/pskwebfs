//
//  AppGenericView.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 6/12/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class AppGenericView: UIView {
    
    @IBOutlet var contentView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit("AppGenericView")
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit("AppGenericView")
    }
    
    func commonInit(_ nibName: String) {
        Bundle.main.loadNibNamed(nibName, owner: self, options: nil)
        addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        contentView.backgroundColor = .clear
    }
}
