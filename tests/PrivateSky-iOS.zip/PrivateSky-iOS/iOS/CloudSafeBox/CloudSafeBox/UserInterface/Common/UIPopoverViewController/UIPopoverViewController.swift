//
//  UIPopoverViewController.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/31/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct UIPopoverVCViewModel {
    let items: [String]
    let cropFrame: CGRect
    let onItemSelection: (_ index: Int) -> ()
}

class UIPopoverViewController: UIViewController {

    private var viewModel: UIPopoverVCViewModel?
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var tableViewHeightConstraint: NSLayoutConstraint!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupControls()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        dismissFromTop()
    }
    
    func setup(with model: UIPopoverVCViewModel) {
        viewModel = model
    }
    
    private func setupControls() {
        setupTableView()
        setupPopover()
    }
    
    private func setupTableView() {
        if let viewModel = viewModel {
            tableViewHeightConstraint.constant = CGFloat(viewModel.items.count) * UIPopoverVCTableViewCell.prefferedHeight()
        }
        tableView.delegate = self
        tableView.dataSource = self
        let nib = UINib(nibName: "UIPopoverVCTableViewCell", bundle: nil)
        tableView.register(nib, forCellReuseIdentifier: UIPopoverVCTableViewCell.reuseId())
        tableView.reloadData()
    }
    
    private func setupPopover() {
        cropOriginControl()
    }
    
    private func cropOriginControl() {
        guard let viewModel = viewModel else { return }
        let overlay = UIView.getOverlayWithCircleCrop(center: viewModel.cropFrame.origin,
                                                      bounds: view.bounds,
                                                      width: viewModel.cropFrame.width,
                                                      height: viewModel.cropFrame.height,
                                                      backgroundColor: .black,
                                                      alpha: 0.3)
        view.insertSubview(overlay, at: 0)
    }
}

extension UIPopoverViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel?.items.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: UIPopoverVCTableViewCell.reuseId(), for: indexPath) as! UIPopoverVCTableViewCell
        cell.setup(withTitle: viewModel?.items[indexPath.row] ?? "")
        return cell;
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UIPopoverVCTableViewCell.prefferedHeight()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        viewModel?.onItemSelection(indexPath.row)
    }
}

