//
//  UIAppNavigationBar.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/31/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct UIAppNavigationBarViewModel {
    let title: String
    let isLeftButtonHidden: Bool
    let isRightButtonHidden: Bool
    let leftButtonImage: UIImage?
    let rightButtonImage: UIImage?
    let onLeftButtonTap: (() -> ())?
    let onRightButtonTap: (() -> ())?
}

@IBDesignable
class UIAppNavigationBar: AppDesignableView {
    
    private var viewModel: UIAppNavigationBarViewModel?

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var leftButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    
    @IBAction func didTapLeftButton(_ sender: Any) {
        viewModel?.onLeftButtonTap?()
    }
    
    @IBAction func didTapRightButton(_ sender: Any) {
        viewModel?.onRightButtonTap?()
    }
    
    func changeRightNavBarButtonImage(withImage img: UIImage?) {
        rightButton.setImage(img, for: .normal)
    }
    
    func setup(with viewModel: UIAppNavigationBarViewModel) {
        titleLabel.textColor = .mainText()
        leftButton.backgroundColor = .highlight()
        rightButton.backgroundColor = .highlight()
        self.viewModel = viewModel
        titleLabel.text = viewModel.title
        leftButton.setImage(viewModel.leftButtonImage?.withRenderingMode(.alwaysTemplate), for: .normal)
        rightButton.setImage(viewModel.rightButtonImage?.withRenderingMode(.alwaysTemplate), for: .normal)
        leftButton.tintColor = .white
        rightButton.tintColor = .white
        leftButton.isHidden = viewModel.isLeftButtonHidden
        rightButton.isHidden = viewModel.isRightButtonHidden
    }
}
