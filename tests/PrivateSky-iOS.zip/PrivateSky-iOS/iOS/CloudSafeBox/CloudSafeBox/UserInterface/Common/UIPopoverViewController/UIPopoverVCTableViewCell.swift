//
//  UIPopoverVCTableViewCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/31/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

class UIPopoverVCTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        titleLabel.textColor = .mainText()
    }
    
    func setup(withTitle title: String) {
        titleLabel.text = title
    }
    
    static func reuseId() -> String {
        return "UIPopoverVCTableViewCellReuseIdentifier"
    }
    
    static func prefferedHeight() -> CGFloat {
        return 50.0
    }
    
}
