//
//  SBRadioButtonView.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/9/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct SBRadioButtonViewModel {
    let title: String
    var isSelected: Bool
    let orderIndex: Int
    let onSelection: (_ index: Int?) -> Void
}

class SBRadioButtonView: UIView {

    private var model: SBRadioButtonViewModel?
    
    @IBOutlet var contentView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var radioImageView: UIImageView!
    
    @IBAction func didTapRadioButton(_ sender: Any) {
        model?.onSelection(model?.orderIndex)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func update(with model: SBRadioButtonViewModel?) {
        guard let model = model else { return }
        self.model = model
        self.titleLabel.text = model.title
        self.radioImageView.setImage(named: model.isSelected ? "selected_icon_" : "unselected_icon_", withTintColor: .white)
    }
    
    func update(isSelected: Bool) {
        self.radioImageView.setImage(named: isSelected ? "selected_icon_" : "unselected_icon_", withTintColor: .white)
    }
}

private extension SBRadioButtonView {
    
    func commonInit() {
        Bundle.main.loadNibNamed("SBRadioButtonView", owner: self, options: nil)
        addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        contentView.backgroundColor = .clear
    }
}
