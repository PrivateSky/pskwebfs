//
//  UINoContentView.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 5/31/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

@IBDesignable
class UINoContentView: AppDesignableView {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var logoImageView: UIImageView!
    
    func setup(withTitle title: String) {
        titleLabel.text = title
    }
}
