import UIKit

struct SBRadioInputViewViewModel {
    let title: String
    let options: Array<String>
    var selectedOption: Int
    let onOptionSelection: (_ optionIndex: Int) -> Void
}

class SBRadioInputView: SwiftyOnboardPage {

    @IBOutlet var contentView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var stackViewHeightConstraint: NSLayoutConstraint!
    
    private let radioButtonHeight: CGFloat = 50.0
    private var viewModel: SBRadioInputViewViewModel?
    private var radioButtons = Array<SBRadioButtonView>()

    class func instanceFromNib() -> UIView {
        return UINib(nibName: "SBRadioInputView", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    func setup(with viewModel: SBRadioInputViewViewModel?) {
        stackView.removeAllArrangedSubviews()
        radioButtons = Array<SBRadioButtonView>()
        guard let viewModel = viewModel else { return }
        self.viewModel = viewModel
        titleLabel.text = viewModel.title
        var index = 0
        viewModel.options.forEach { (option) in
            let radioButton = SBRadioButtonView(frame: CGRect(x: 0, y: 0, width: stackView.frame.width, height: radioButtonHeight))
            radioButton.update(with: SBRadioButtonViewModel(title: option, isSelected: viewModel.selectedOption == index, orderIndex: index, onSelection: { (selIndex) in
                guard let selIndex = selIndex else { return }
                self.viewModel!.selectedOption = selIndex
                self.updateRadioButtonsAndNotify()
            }))
            radioButtons.append(radioButton)
            index += 1
        }
        stackViewHeightConstraint.constant = CGFloat(radioButtons.count) * radioButtonHeight
        radioButtons.forEach { (button) in
            stackView.addArrangedSubview(button)
        }
    }
    
    func updateRadioButtonsAndNotify() {
        var index = 0
        radioButtons.forEach { (button) in
            button.update(isSelected: index == viewModel?.selectedOption)
            index += 1
        }
        guard let viewModel = viewModel else { return }
        viewModel.onOptionSelection(viewModel.selectedOption)
    }

}

private extension SBRadioInputView {
    
    func commonInit() {
        Bundle.main.loadNibNamed("SBRadioInputView", owner: self, options: nil)
        addSubview(contentView)
        contentView.frame = self.bounds
        contentView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        contentView.backgroundColor = UIColor.wizardBackground()
        titleLabel.textColor = .white
    }
}
