//
//  CSBTicketTableViewCell.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/30/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

enum CSBTicketTVCDataType {
    case password
    case none
}

struct CSBTicketTableViewCellModel {
    let title: String
    let subtitle: String
    let dataType: CSBTicketTVCDataType
    let disclosureHidden: Bool
}

class CSBTicketTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var disclosureImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        addShadow()
        titleLabel.textColor = .mainText()
        subtitleLabel.textColor = .generalText()
    }
    
    func setup(with model: CSBTicketTableViewCellModel?) {
        guard let model = model else { return }
        titleLabel.text = model.title
        subtitleLabel.text = model.subtitle
        disclosureImageView.isHidden = model.disclosureHidden
    }
    
    static func reuseId() -> String {
        return "CSBTicketTableViewCellReuseIdentifier"
    }
}
