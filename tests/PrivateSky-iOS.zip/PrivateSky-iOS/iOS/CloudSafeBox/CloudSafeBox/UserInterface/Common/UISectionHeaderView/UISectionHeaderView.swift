//
//  UISectionHeaderView.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 6/12/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

struct UISectionHeaderViewModel {
    let title: String
    let image: UIImage?
    let isExpanded: Bool
    let onSectionSelection: (() -> ())?
}

class UISectionHeaderView: AppGenericView {
    
    private var viewModel: UISectionHeaderViewModel?

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var logoImageView: UIImageView!
    @IBOutlet weak var stateImageView: UIImageView!
    
    @IBAction func selectSection(_ sender: Any) {
        viewModel?.onSectionSelection?()
    }
    
    func setup(with model: UISectionHeaderViewModel?) {
        titleLabel.textColor = UIColor.mainText()
        stateImageView.setTintColor(tintColor: UIColor.separatorColor())
        guard let viewModel = model else { return }
        self.viewModel = viewModel
        titleLabel.text = viewModel.title
        logoImageView.image = viewModel.image
        stateImageView.transform = viewModel.isExpanded ? CGAffineTransform.identity.rotated(by: CGFloat.pi/2) : CGAffineTransform.identity
    }
    
    override func commonInit(_ nibName: String) {
        super.commonInit("UISectionHeaderView")
    }
}
