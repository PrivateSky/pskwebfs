import UIKit

extension UIViewController {
    func showMessage(title: String, message: String) {
        SBAlertViewController.presentOkAlert(from: self, title: title, message: message)
    }
}
