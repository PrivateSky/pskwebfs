//
//  UITextField+Utils.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 4/18/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

extension UITextField {

    func newText(fromRange range: NSRange, withReplacementString string: String) -> String {
        guard let selfText = self.text else { return "" }
        let newText = (selfText as NSString).replacingCharacters(in: range, with: string)
        return newText
    }
}
