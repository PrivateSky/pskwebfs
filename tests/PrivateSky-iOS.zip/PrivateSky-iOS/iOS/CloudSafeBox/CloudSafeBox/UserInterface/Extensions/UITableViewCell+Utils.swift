//
//  UITableViewCell+Utils.swift
//  STAR
//
//  Created by Catalin Pomirleanu on 12/7/17.
//  Copyright © 2017 RomSoft. All rights reserved.
//

import UIKit

let CustomSeparatorViewHeight: CGFloat = 0.5
let CustomSeparatorViewTag = 943472

extension UITableViewCell {
    
    func addCustomSeparatorView() {
        removeCustomSeparatorView()
        
        let separatorView = UIView(frame: CGRect(x: 0.0, y: contentView.frame.height - CustomSeparatorViewHeight, width: contentView.frame.width, height: CustomSeparatorViewHeight))
        separatorView.autoresizingMask = [UIViewAutoresizing.flexibleTopMargin, UIViewAutoresizing.flexibleWidth]
        separatorView.backgroundColor = UIColor.separatorColor()
        contentView.addSubview(separatorView)
    }
    
    func removeCustomSeparatorView() {
        contentView.viewWithTag(CustomSeparatorViewTag)?.removeFromSuperview()
    }
}
