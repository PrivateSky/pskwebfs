//
//  UIView+Utils.swift
//  STAR
//
//  Created by Catalin Pomirleanu on 11/8/17.
//  Copyright © 2017 RomSoft. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func dismissFromTop() {
        let transition: CATransition = CATransition()
        transition.duration = 0.5
        transition.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
        transition.type = kCATransitionFade
        transition.subtype = kCATransitionMoveIn
        self.view.window!.layer.add(transition, forKey: nil)
        self.dismiss(animated: false, completion: nil)
    }
    
    func setAppGradientBackground() {
        let gradient = CAGradientLayer()
        gradient.frame = view.bounds
        gradient.colors = [UIColor.background().cgColor, UIColor.backgroundBottom().cgColor]
        view.layer.insertSublayer(gradient, at: 0)
    }
}

extension UIView {

    func setKeyboardToHideAtExternalTap() {
        let tap = UITapGestureRecognizer( target: self, action: #selector(UIView.dismissKeyboard))
        self.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        self.endEditing(true)
    }
    
    func loadNib() -> UIView? {
        let bundle = Bundle(for: type(of: self))
        guard let nibName = type(of: self).description().components(separatedBy: ".").last else { return nil }
        let nib = UINib(nibName: nibName, bundle: bundle)
        return nib.instantiate(withOwner: self, options: nil).first as? UIView
    }
    
    func addShadow() {
        layer.shadowColor = UIColor.shadow().cgColor
        layer.shadowOffset = CGSize(width: 3, height: 5)
        layer.shadowRadius = 2.0
        layer.shadowOpacity = 1.0
        layer.masksToBounds = false;
        layer.shadowPath = UIBezierPath(roundedRect: bounds, cornerRadius: self.layer.cornerRadius).cgPath
    }
    
    static func getOverlayWithCircleCrop(center: CGPoint, bounds: CGRect, width: CGFloat, height: CGFloat, backgroundColor bgColor: UIColor, alpha: CGFloat) -> UIView {
        let shapeLayer = CAShapeLayer()
        
        let path = UIBezierPath(rect: bounds)
        path.addArc(withCenter: CGPoint(x: center.x + width/2, y: center.y + height/2), radius: width/2, startAngle: 0, endAngle: CGFloat(2 * Double.pi), clockwise: true)
        path.close()
        
        shapeLayer.fillRule = kCAFillRuleEvenOdd
        shapeLayer.path = path.reversing().cgPath
        
        let overlay = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        overlay.layer.mask = shapeLayer
        overlay.clipsToBounds = true
        
        overlay.alpha = alpha
        overlay.backgroundColor = bgColor
        
        return overlay
    }
}
