//
//  UIButton+Utils.swift
//  STAR
//
//  Created by Catalin Pomirleanu on 12/8/17.
//  Copyright © 2017 RomSoft. All rights reserved.
//

import UIKit

extension UIBarButtonItem {
    
    static func create(systemItem: UIBarButtonSystemItem?, image: UIImage?, title: String?, tintColor: UIColor, target: Any?, action: Selector?) -> UIBarButtonItem {
        var result = UIBarButtonItem()
        if let systemItem = systemItem {
            result = UIBarButtonItem(barButtonSystemItem: systemItem, target: target, action: action)
        } else {
            result = UIBarButtonItem(image: image, style: .plain, target: target, action: action)
            result.title = title
        }
        
        result.tintColor = tintColor
        return result
    }
}
