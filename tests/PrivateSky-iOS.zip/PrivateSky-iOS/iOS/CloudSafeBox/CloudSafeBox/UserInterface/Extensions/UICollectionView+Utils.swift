import UIKit

extension UICollectionView {
    func scrollToNextItem() {
        let contentOffset = CGFloat(self.contentOffset.x + self.bounds.size.width)
        self.moveToFrame(contentOffset: contentOffset)
    }
    
    func scrollToPreviousItem() {
        let contentOffset = CGFloat(self.contentOffset.x - self.bounds.size.width)
        self.moveToFrame(contentOffset: contentOffset)
    }
    
    func moveToFrame(contentOffset : CGFloat) {
        let frame: CGRect = CGRect(x: contentOffset, y: self.contentOffset.y , width: self.frame.width, height: self.frame.height)
        self.scrollRectToVisible(frame, animated: true)
    }
}
