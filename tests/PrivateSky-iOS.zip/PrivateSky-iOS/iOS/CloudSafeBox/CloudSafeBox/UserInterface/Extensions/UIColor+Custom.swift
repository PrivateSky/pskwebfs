//
//  UIColor+Custom.swift
//  STAR
//
//  Created by Catalin Pomirleanu on 11/8/17.
//  Copyright © 2017 RomSoft. All rights reserved.
//

import UIKit

fileprivate let ColorHexValue : CGFloat = 255.0
fileprivate let AlphaZero : CGFloat = 0.0
fileprivate let AlphaOne : CGFloat = 1.0

extension UIColor {
    
    // MARK: - Private Methods
    fileprivate static func customColor(red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat = AlphaOne) -> UIColor {
        return UIColor(red: red / ColorHexValue, green: green / ColorHexValue, blue: blue / ColorHexValue, alpha: alpha)
    }
    
    // MARK: - Public Methods
    static func separatorColor() -> UIColor {
        return customColor(red: 221.0, green: 221.0, blue: 221.0)
    }
    
    static func highlight() -> UIColor {
        return customColor(red: 7, green: 115, blue: 254)
    }
    
    static func strongHighlight() -> UIColor {
        return customColor(red: 34, green: 73, blue: 117)
    }
    
    static func background() -> UIColor {
        return customColor(red: 252, green: 252, blue: 253)
    }
    
    static func backgroundBottom() -> UIColor {
        return customColor(red: 245, green: 247, blue: 249)
    }
    
    static func shadow() -> UIColor {
        return customColor(red: 234, green: 240, blue: 243)
    }
    
    static func mainText() -> UIColor {
        return customColor(red: 34, green: 73, blue: 117)
    }
    
    static func generalText() -> UIColor {
        return customColor(red: 59, green: 98, blue: 142)
    }
    
    static func inactiveControl() -> UIColor {
        return customColor(red: 159, green: 159, blue: 159)
    }
    
    static func listItemBackground() -> UIColor {
        return customColor(red: 255, green: 255, blue: 255)
    }
    
    static func warning() -> UIColor {
        return customColor(red: 209, green: 64, blue: 79)
    }
    
    static func pwdVeryWeak() -> UIColor {
        return customColor(red: 120, green: 120, blue: 120)
    }
    
    static func pwdWeak() -> UIColor {
        return customColor(red: 132, green: 37, blue: 52)
    }
    
    static func pwdReasonable() -> UIColor {
        return customColor(red: 240, green: 198, blue: 89)
    }
    
    static func pwdStrong() -> UIColor {
        return customColor(red: 127, green: 157, blue: 178)
    }
    
    static func pwdVeryStrong() -> UIColor {
        return customColor(red: 27, green: 115, blue: 26)
    }
    
    static func menuBackground() -> UIColor {
        return customColor(red: 14, green: 25, blue: 99)
    }
    
    static func wizardBackground() -> UIColor {
        return customColor(red: 14, green: 25, blue: 99)
    }
}
