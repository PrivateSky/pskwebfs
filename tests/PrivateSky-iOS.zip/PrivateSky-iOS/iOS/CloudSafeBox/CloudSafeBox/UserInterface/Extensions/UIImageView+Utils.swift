//
//  UIImageView+Utils.swift
//  STAR
//
//  Created by Catalin Pomirleanu on 12/6/17.
//  Copyright © 2017 RomSoft. All rights reserved.
//

import UIKit

extension UIImageView {
    
    func setImage(named imageName: String, withTintColor tintColor: UIColor) {
        guard let sourceImage = UIImage(named: imageName) else { return }
        
        self.image = sourceImage.withRenderingMode(.alwaysTemplate)
        self.tintColor = tintColor
    }
    
    func setTintColor(tintColor: UIColor) {
        guard let selfImage = self.image else { return }
        self.image = selfImage.withRenderingMode(.alwaysTemplate)
        self.tintColor = tintColor
    }
}
