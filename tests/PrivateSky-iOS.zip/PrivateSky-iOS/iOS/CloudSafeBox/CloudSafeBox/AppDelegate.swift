//
//  AppDelegate.swift
//  CloudSafeBox
//
//  Created by Catalin Pomirleanu on 3/28/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit
import CloudSafeBoxCore

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        IQKeyboardManager.shared.enable = true
        launchUI()
        DependenciesManager.config().setup()
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        
    }

    func applicationWillTerminate(_ application: UIApplication) {
        
    }
    
    // MARK: - Helpers
    private func launchUI() {
        window = UIWindow(frame: UIScreen.main.bounds)
        SBControllersContainer.launch(with: window)
        self.window?.makeKeyAndVisible()
    }
}
