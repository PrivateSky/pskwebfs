import UIKit

extension NSDictionary  {
    func arrayValue(key: String) -> NSArray {
        if let castedSelf = self as? [String: AnyObject] {
            let value: AnyObject? = castedSelf[key]
            
            if let currentValue = value as? NSArray {
                return currentValue
            } else if let currentValue = value as? NSDictionary {
                return [currentValue]
            } else {
                return []
            }
        }
        
        return []
    }
    
    func stringValue(key: String) -> String {
        if let castedSelf = self as? [String: AnyObject] {
            let value: AnyObject? = castedSelf[key]
            
            if let currentValue = value as? String {
                return currentValue
            } else {
                return ""
            }
        }
        
        return ""
    }
    
    func intValue(key: String, defaultValue: Int) -> Int {
        
        if let castedSelf = self as? [String: AnyObject] {
            if let value: AnyObject = castedSelf[key] {
                if let intValue = Int(value as? String ?? "") {
                    return intValue
                }
            }
        }
        
        return defaultValue
    }
    
    func intValue(key: String) -> Int {
        return intValue(key: key, defaultValue: 0)
    }
    
    func dictionaryValue(key: String) -> NSDictionary {
        if let castedSelf = self as? [String: AnyObject] {
            let value: AnyObject? = castedSelf[key]
            
            if let currentValue = value as? NSDictionary {
                return currentValue
            } else {
                return NSDictionary()
            }
        }
        
        return NSDictionary()
    }
    
    func optionalDictionaryValue(key: String) -> NSDictionary? {
        if let castedSelf = self as? [String: AnyObject] {
            let value: AnyObject? = castedSelf[key]
            var returnValue: NSDictionary?
            
            if let currentValue = value as? NSDictionary {
                returnValue = currentValue
            }
            
            return returnValue
        }
        
        return nil
    }
}
