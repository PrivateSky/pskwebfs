import UIKit

extension String {

    func isEmptyOrBlank() -> Bool {
        return self == "" || self == " "
    }
    
    static func safeString(stringValue: Any?) -> String {
        if let returnString = stringValue as? String {
            return returnString
        } else {
            return ""
        }
    }
    
    static func isNullEmptyOrSpace(_ string: String?) -> Bool {
        guard let string = string else { return true }
        return string == "" || string == " "
    }
    
    static func isEmptyOrSpace(_ string: String) -> Bool {
        return string == "" || string == " "
    }
    
    func toDate(dateFormat format: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = format
        if let timeZone = NSTimeZone(name: "UTC") as TimeZone? {
            dateFormatter.timeZone = timeZone
        }
        return dateFormatter.date(from: self)
    }
    
    func removeLeadingZero() -> String {
        if self.hasPrefix("0") && !self.isEmpty {
            return (self as NSString).substring(from: 1)
        } else {
            return self
        }
    }
    
    func getInitials() -> String {
        var initials = ""
        
        let splitted = self.split(separator: " ")
        for word in splitted {
            if let initial = word.first {
                initials = "\(initials)\(initial)"
            }
        }
        
        return initials
    }
    
    func toBool() -> Bool? {
        switch self {
        case "True", "true", "yes", "1":
            return true
        case "False", "false", "no", "0":
            return false
        default:
            return nil
        }
    }
}
