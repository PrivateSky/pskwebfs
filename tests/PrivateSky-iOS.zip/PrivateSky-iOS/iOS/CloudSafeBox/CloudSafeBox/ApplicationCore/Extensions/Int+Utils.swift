import UIKit

extension Int {

    func toNumber() -> NSNumber {
        return NSNumber(value: self)
    }
}
