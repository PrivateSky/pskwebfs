import UIKit
import SwiftDate

let EN_US_POSIX_LocaleIdentifier = "en_US_POSIX"

enum SBDateFormat: String {
    case defaultSimpleFormat        = "yyyy-MM-dd'T'HH:mm:ss"
    case defaultSimpleFormatZulu    = "yyyy-MM-dd'T'HH:mm:ss.zzz"
    case dateFormat                 = "dd-MM-yyyy"
    case detailedDateTime           = "EEEE, MMMM d, yyyy, HH:mm"
}

extension Date {
    
    func dateElements() -> (day: Int, month: Int, year: Int) {
        return (day: self.day, month: self.month, year: self.year)
    }
    
    func toDetailedDateTimeString() -> String {
        return stringDate(dateFormat: SBDateFormat.detailedDateTime.rawValue)
    }
    
    func stringDate(dateFormat: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: EN_US_POSIX_LocaleIdentifier)
        dateFormatter.dateFormat = dateFormat
        
        return dateFormatter.string(from: self).removeLeadingZero()
    }
}
