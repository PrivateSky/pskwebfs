#import <UIKit/UIKit.h>

FOUNDATION_EXPORT double CloudSafeBoxCoreVersionNumber;

FOUNDATION_EXPORT const unsigned char CloudSafeBoxCoreVersionString[];


