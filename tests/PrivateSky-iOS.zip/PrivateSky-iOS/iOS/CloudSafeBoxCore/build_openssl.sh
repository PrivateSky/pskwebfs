#!/bin/bash
# Jonathan Cardasis - 2018
# Builds OpenSSL libssl and libcrypto for macOS
# binary distribution (i386 and x86).

VERSION="1.1.0h"
VERSION_SHA256_CHECKSUM="5835626cde9e99656585fc7aaa2302a73a7e1340bf8c14fd635a62c66802a517"

####################################
curl -O https://www.openssl.org/source/openssl-$VERSION.tar.gz

# Run a checksum to ensure this file wasn't tampered with
FILE_CHECKSUM=$(shasum -a 256 openssl-$VERSION.tar.gz | awk '{print $1; exit}')
if [ "$FILE_CHECKSUM" != "$VERSION_SHA256_CHECKSUM" ]; then
  echo "OpenSSL v$VERSION failed checksum. Please ensure that you are on a trusted network."
  exit 1
fi

OPENSSL_FOLDER="OpenSSL"

# Create openssl folder structure, hidden at first
mkdir ".$OPENSSL_FOLDER"
OPENSSL_LIB_FOLDER=".$OPENSSL_FOLDER/lib"
OPENSSL_INCLUDE_FOLDER=".$OPENSSL_FOLDER/include"
mkdir "$OPENSSL_LIB_FOLDER"

# Unzip into i386 and x86 64bit folders
tar -xvzf openssl-$VERSION.tar.gz
mv openssl-$VERSION openssl_arm64

# Build Flavors
cd openssl_arm64
./Configure darwin64-arm64-cc
echo "Building arm64 static library..."
make >> /dev/null 2>&1
make install >> /dev/null 2>&1
cd ../

# Copy include and License into main OpenSSL folder (done after configure so <openssl/opensslconf.h> can be generated)
cd openssl_arm64
cp -r include "../.$OPENSSL_FOLDER" # Copy include headers into hidden folder
cp LICENSE "../.$OPENSSL_FOLDER" # Copy License
cd ../

# Link
echo "Linking..."
lipo -create openssl_arm64/libcrypto.a -output "$OPENSSL_LIB_FOLDER/libcrypto.a"
lipo -create openssl_arm64/libssl.a -output "$OPENSSL_LIB_FOLDER/libssl.a"

# Cleanup
rm openssl-$VERSION.tar.gz
rm -r openssl_arm64
mv ".$OPENSSL_FOLDER" "$OPENSSL_FOLDER"

echo "Finished OpenSSL generation script."
