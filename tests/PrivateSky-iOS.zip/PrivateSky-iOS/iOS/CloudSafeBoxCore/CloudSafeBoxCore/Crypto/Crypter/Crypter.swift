import Foundation
public protocol Crypter {
    func encrypt(data: Data, password: Data, completion: (_ encryptedData: Data?) -> Void)
    func decrypt(encryptedData: Data, password: Data, completion: (_ data: Data?) -> Void)
    func provideDerivedSeed(from seed: String, dseedLen: Int, completion: (_ derivedSeed: Data?) -> Void)
    func encryptDSeed(_ dseed: [UInt8], pin: String, completion: (_ encryptedDSeed: Data?) -> Void)
    func decryptDSeed(_ encryptedDSeed: Data, pin: String, completion: (_ derivedSeed: String?) -> Void)
}
