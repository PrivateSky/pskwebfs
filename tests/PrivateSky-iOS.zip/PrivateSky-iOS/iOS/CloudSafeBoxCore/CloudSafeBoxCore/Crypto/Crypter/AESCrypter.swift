import Foundation
class AESCrypter: Crypter {
    
    private let DEFAULT_ITERATIONS_NUMBER = 1000
    
    func encrypt(data: Data, password: Data, completion: (_ encryptedData: Data?) -> Void) {
        guard let keySalt = DependenciesManager.dataBinder().buildRandomBytes(bytesCount: 32),
            let aadSalt = DependenciesManager.dataBinder().buildRandomBytes(bytesCount: 32)
            else { completion(nil); return }
        
        do {
            let key = try PKCS5.PBKDF2(password: password.bytes, salt: keySalt.bytes, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 32, variant: HMAC.Variant.sha512).calculate()
            let aad = try PKCS5.PBKDF2(password: password.bytes, salt: aadSalt.bytes, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 32, variant: HMAC.Variant.sha512).calculate()
            let salt = keySalt.bytes + aadSalt.bytes
            let iv = try PKCS5.PBKDF2(password: password.bytes, salt: salt, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 12, variant: HMAC.Variant.sha512).calculate()
            
            let gcm = GCM(iv: iv, additionalAuthenticatedData: aad, mode: GCM.Mode.combined)
            let encryptor = try AES(key: key, blockMode: gcm)
            let encryptedData = try encryptor.encrypt(data.bytes)
            
            let finalBytes = salt + encryptedData
            completion(Data(bytes: finalBytes))
        } catch {
            completion(nil)
        }
    }
    
    func decrypt(encryptedData: Data, password: Data, completion: (_ data: Data?) -> Void) {
        let salt = Array(encryptedData.bytes.prefix(through: 63))
        let keySalt = Array(salt.prefix(through: 31))
        let aadSalt = Array(salt.suffix(from: 32))
        
        do {
            let iv = try PKCS5.PBKDF2(password: password.bytes, salt: salt, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 12, variant: HMAC.Variant.sha512).calculate()
            let key = try PKCS5.PBKDF2(password: password.bytes, salt: keySalt, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 32, variant: HMAC.Variant.sha512).calculate()
            let aad = try PKCS5.PBKDF2(password: password.bytes, salt: aadSalt, iterations: DEFAULT_ITERATIONS_NUMBER, keyLength: 32, variant: HMAC.Variant.sha512).calculate()
            
            let ciphertext = Array(encryptedData.bytes[64...encryptedData.count - 17])
            let tag = Array(encryptedData.bytes.suffix(from: encryptedData.count - 16))
            
            let gcm = GCM(iv: iv, authenticationTag: tag, additionalAuthenticatedData: aad, mode: GCM.Mode.detached)
            let decryptor = try AES(key: key, blockMode: gcm)
            let decryptedData = try decryptor.decrypt(ciphertext)
            completion(Data(bytes: decryptedData))
        } catch {
            completion(nil)
        }
    }
    
    func provideDerivedSeed(from seed: String, dseedLen: Int, completion: (_ derivedSeed: Data?) -> Void) {
        guard let dseed = deriveKey(for: seed, keyLength: dseedLen) else { completion(nil); return }
        completion(Data(bytes: dseed))
        //encryptDSeed(dseed, pin: pin, completion: completion)
    }
    
    func encryptDSeed(_ dseed: [UInt8], pin: String, completion: (_ encryptedDSeed: Data?) -> Void) {
        guard let encryptionKey = deriveKey(for: pin),
            let iv = DependenciesManager.dataBinder().buildRandomBytes(bytesCount: 16)
            else { completion(nil); return }
        
        do {
            let encryptor = try AES(key: encryptionKey, blockMode: CFB(iv: iv.bytes))
            let encryptedDSeed = try encryptor.encrypt(dseed)
            completion(Data(bytes: iv + encryptedDSeed))
        } catch {
            completion(nil)
        }
    }
    
    func decryptDSeed(_ encryptedDSeed: Data, pin: String, completion: (_ derivedSeed: String?) -> Void) {
        guard let encryptionKey = deriveKey(for: pin) else { completion(nil); return }
        let iv = Array(encryptedDSeed.bytes.prefix(through: 15))
        do {
            let decryptor = try AES(key: encryptionKey, blockMode: CFB(iv: iv))
            let decryptedDSeed = try decryptor.decrypt(encryptedDSeed.bytes.suffix(from: 16))
            completion(String(bytes: decryptedDSeed, encoding: .utf8))
        } catch {
            completion(nil)
        }
    }
    
    private func generateSalt(for data: Data, saltLength: Int) -> Data {
        let dataHash = data.sha512()
        let range: Range = 0..<saltLength
        return dataHash.subdata(in: range)
    }
    
    private func deriveKey(for value: String, iterations: Int = 1000, keyLength: Int = 32) -> [UInt8]? {
        guard let valueData = value.data(using: .utf8) else { return nil }
        do {
            let derivedData = try PKCS5.PBKDF2(password: Array(value.utf8),
                                               salt: generateSalt(for: valueData, saltLength: 32).bytes,
                                               iterations: iterations,
                                               keyLength: keyLength,
                                               variant: HMAC.Variant.sha512).calculate()
            return derivedData
        } catch {
            print("Did return nil when providing derived data for: \(value)")
            return nil
        }
    }
}
