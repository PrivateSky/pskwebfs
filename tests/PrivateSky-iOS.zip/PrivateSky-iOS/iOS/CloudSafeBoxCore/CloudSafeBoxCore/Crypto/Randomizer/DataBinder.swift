import Security
import Foundation

class DataBinder: IDataBinder {
    
    private let randomWordsFileName = "random_words"
    
    func buildRandomWords(withCount count: Int) -> [String] {
        guard let randomWordsFilePath = Bundle.frameworkBundle?.path(forResource: randomWordsFileName, ofType: "txt") else { return [] }
        do {
            let text = try String(contentsOfFile: randomWordsFilePath)
            let words = text.components(separatedBy: "\n")
            let wordsCount = words.count
            
            var selectedWords = [String]()
            var selectedIndexes = [UInt32]()
            
            for _ in 0..<count {
                let randomWordIndex = arc4random_uniform(UInt32(wordsCount))
                if !selectedIndexes.contains(randomWordIndex) {
                    selectedWords.append(words[Int(randomWordIndex)])
                    selectedIndexes.append(randomWordIndex)
                }
            }
            
            return selectedWords
            
        } catch {
            return []
        }
    }
    
    func buildRandomBytes(bytesCount: Int) -> Data? {
        var randomBytes = [UInt8](repeating: 0, count: bytesCount)
        let status = SecRandomCopyBytes(kSecRandomDefault, bytesCount, &randomBytes)
        if status != errSecSuccess { return nil }
        return Data(bytes: randomBytes)
    }
    
    func buildEncryptedFileName(from params: [Any]) -> String {
        var joinedParams = ""
        
        params.forEach { (param) in
            if let param = param as? String {
                joinedParams += param
            } else if let paramData = param as? Data {
                let joinedBytes = paramData.bytes.map { String($0) }.joined()
                joinedParams += joinedBytes
            }
        }
        
        let fileName = joinedParams.sha512()
        return fileName
    }
}
