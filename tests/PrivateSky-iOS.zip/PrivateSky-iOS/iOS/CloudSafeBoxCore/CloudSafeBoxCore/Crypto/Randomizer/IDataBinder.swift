import Foundation
public protocol IDataBinder {
    func buildRandomWords(withCount count: Int) -> [String]
    func buildRandomBytes(bytesCount: Int) -> Data?
    func buildEncryptedFileName(from params: [Any]) -> String 
}
