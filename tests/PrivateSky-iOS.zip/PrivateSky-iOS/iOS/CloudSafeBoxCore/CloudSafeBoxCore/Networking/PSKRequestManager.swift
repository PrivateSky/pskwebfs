import Foundation

class PSKRequestManager {
    
    private let pollingTimeout: Int

    init(pollingTimeout: Int) {
        self.pollingTimeout = pollingTimeout
    }
    
    
}

class PSKRequest {
    
    private let endpoint: String
    private let initialSwarm: PSKSwarm
    
    init(endpoint: String, initialSwarm: PSKSwarm) {
        self.endpoint = endpoint
        self.initialSwarm = initialSwarm
    }
    
}

struct PSKSwarm {
    let meta: PSKSwarmMeta
}

struct PSKSwarmMeta {
    let swarmId: String
    let requestId: String
    let swarmTypeName: String
    let phaseName: String
    let args: Array<Any>
    let command: String
    let target: String
    
    init(swarmName: String, phaseName: String, command: String?, agentUid: String, args: Array<Int>) {
        self.swarmId = UUID().uuidString
        self.requestId = self.swarmId
        self.swarmTypeName = swarmName
        self.phaseName = phaseName
        self.args = args
        self.command = command ?? "relay"
        self.target = agentUid
    }
}
