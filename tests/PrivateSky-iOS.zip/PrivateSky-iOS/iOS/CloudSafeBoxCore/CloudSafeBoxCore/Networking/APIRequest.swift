import Foundation

struct APIRequest: IAPIRequest {
    var baseURL: URL?
    var path: String
    var method: HTTPMethod
    var reqParameters: APIRequestParams
    var headers: [String: String]?
}
