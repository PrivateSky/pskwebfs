import Foundation

enum APIDataType {
    case JSON
    case Data
}

enum HTTPMethod: String {
    case post   = "POST"
    case put    = "PUT"
    case get    = "GET"
    case delete = "DELETE"
    case patch  = "PATCH"
}

enum APIRequestParams {
    case body(_ : Dictionary<String,Any>?)
    case url(_ : Dictionary<String,Any>?)
}

protocol IAPIRequest {
    var baseURL: URL? { get }
    var path: String { get }
    var method: HTTPMethod { get }
    var reqParameters: APIRequestParams { get }
    var headers: [String: String]? { get }
    var dataType: APIDataType { get }
}

extension IAPIRequest {
    
    var dataType: APIDataType {
        return .JSON
    }
}

extension IAPIRequest {
    
    func sendRequest(from session: URLSession, completion: @escaping (_ data: Data?, _ error: Error?) -> Void)  {
        guard let request = buildRequest() else { completion(nil, nil); return }
        
        let task = session.dataTask(with: request, completionHandler: { (data, taskResponse, error) in
            completion(data, error)
        })
        
        task.resume()
    }
    
    func buildRequest() -> URLRequest? {
        guard let baseURL = baseURL,
            var urlComponents = URLComponents(url: baseURL, resolvingAgainstBaseURL: true) else { return nil }
        
        let reqParams = queryAndBody(from: reqParameters)
        
        urlComponents.path = urlComponents.path + path
        urlComponents.queryItems = reqParams.query
        
        guard let url = urlComponents.url else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        request.httpBody = reqParams.body
        
        if let headers = headers {
            headers.keys.forEach({ (key) in
                guard let value = headers[key] else { return }
                request.addValue(value, forHTTPHeaderField: key)
            })
        }
        
        return request
    }
    
    private func queryAndBody(from params: APIRequestParams) -> (query: [URLQueryItem]?, body: Data?) {
        switch params {
        case .url(let queryParams):
            return (queryParameters(from: queryParams), nil)
        case .body(let bodyParams):
            return (nil, body(from: bodyParams))
        }
    }
    
    private func queryParameters(from params: Dictionary<String,Any>?) -> [URLQueryItem]? {
        guard let params = params, params.count > 0, params.count < 15 else { return nil }
        let queryParameters: [URLQueryItem] = params.map { (key, value) in URLQueryItem(name: key, value: String(describing: value)) }
        return queryParameters
    }
    
    private func body(from params: Dictionary<String,Any>?) -> Data? {
        guard let params = params else { return nil }
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: params, options: .prettyPrinted)
            return jsonData
        } catch {
            return nil
        }
    }
}
