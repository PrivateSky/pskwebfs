import UIKit

public protocol ICSBContainer {
    func setupContainer()
    func provideCSBList(completion: (_ csb: [CloudSafeBox], _ error: Error?) -> Void)
    func provideCSB(withId id: String, completion: (_ csb: CloudSafeBox?, _ error: Error?) -> Void)
    func addCSB(_ csb: CloudSafeBox, completion: (_ success: Bool, _ error: Error?) -> Void)
    func deleteCSB(withId id: String, completion: (_ success: Bool, _ error: Error?) -> Void)
}

