import Foundation

public protocol ISensitiveDataContainer {
    func setup()
    func storePIN(_ pin: String)
    func providePIN() -> String
    func saveDSeed(forCSB csbName: String, dseed: Data)
    func getDSeed(forCSB csbName: String) -> Data?
}
