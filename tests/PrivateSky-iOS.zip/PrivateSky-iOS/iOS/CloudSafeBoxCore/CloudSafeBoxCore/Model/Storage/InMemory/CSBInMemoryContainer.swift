import Foundation

class CSBInMemoryContainer: ICSBContainer {
    
    private var safeBoxes = [CloudSafeBox]()
    
    static let shared = CSBInMemoryContainer()
    
    private init() { }
    
    func setupContainer() {
        extractCSBsFromSandbox()
    }
    
    func extractCSBsFromSandbox() {
        let sandbox = DependenciesManager.sandbox()
        let csbPaths = sandbox.getAllCSBPaths()
        for path in csbPaths {
            guard let data = sandbox.readData(atPath: path),
             let dseed = DependenciesManager.sensitiveDataContainer().getDSeed(forCSB: (path as NSString).lastPathComponent) else { return }
            DependenciesManager.crypter().decrypt(encryptedData: data, password: dseed) { (csbData) in
                if let csb = CloudSafeBox(data: csbData) {
                    safeBoxes.append(csb)
                }
            }
        }
    }
    
    func provideCSBList(completion: (_ csb: [CloudSafeBox], _ error: Error?) -> Void) {
        completion(safeBoxes, nil)
    }
    
    func provideCSB(withId id: String, completion: (_ csb: CloudSafeBox?, _ error: Error?) -> Void) {
        completion(safeBoxes.filter({ (csb) -> Bool in return csb.id == id }).first, nil)
    }
    
    func addCSB(_ csb: CloudSafeBox, completion: (_ success: Bool, _ error: Error?) -> Void) {
        safeBoxes.append(csb)
        csb.sendToLocalStorage { (success) in
            completion(success, nil)
        }
    }
    
    func deleteCSB(withId id: String, completion: (_ success: Bool, _ error: Error?) -> Void) {
        if let index = safeBoxes.index(where: { $0.id == id }) {
            safeBoxes.remove(at: index)
            completion(true, nil)
        } else {
            completion(false, CSBContainerOperationError.onDeleteCSB)
        }
    }
}
