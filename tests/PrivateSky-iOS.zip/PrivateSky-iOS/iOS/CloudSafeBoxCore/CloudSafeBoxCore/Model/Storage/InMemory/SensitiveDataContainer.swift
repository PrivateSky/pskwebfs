import Foundation

class SensitiveDataContainer: ISensitiveDataContainer {
    
    private var pin: String = "12345678"
    private var dseeds = [String: Data]()
    
    static let shared = SensitiveDataContainer()
    
    private init() { }
    
    func setup() {
        if let dseeds = SafeAccess.retrieveDSeedsIfAny() {
            self.dseeds = dseeds
        }
    }
    
    func storePIN(_ pin: String) {
        self.pin = pin
    }
    
    func providePIN() -> String {
        return pin
    }
    
    func saveDSeed(forCSB csbName: String, dseed: Data) {
        _ = SafeAccess.saveNewDSeed(for: csbName, dseed: dseed)
    }
    
    func getDSeed(forCSB csbName: String) -> Data? {
        return dseeds[csbName]
    }
}
