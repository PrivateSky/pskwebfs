public enum CSBRecordDataType: String {
    case text       = "text"
    case date       = "date"
    case document   = "document"
}

public struct CSBRecordStructureField {
    public let name: String
    public let dataType: CSBRecordDataType
}

public struct CSBRecordStructure {
    public let categoryName: String
    public let categoryImageName: String
    public private(set) var fields: Array<CSBRecordStructureField>
    
    init?(data: Dictionary<String,Any>?) {
        guard let data = data,
            let categoryName = data["categoryName"] as? String,
            let categoryImageName = data["categoryImageName"] as? String,
            let fields = data["fields"] as? Array<Dictionary<String, String>> else { return nil }
        
        self.categoryName = categoryName
        self.categoryImageName = categoryImageName
        self.fields = Array<CSBRecordStructureField>()
        fields.forEach { (field) in
            guard let name = field["fieldName"],
            let dataTypeString = field["dataType"],
                let dataType = CSBRecordDataType(rawValue: dataTypeString) else {
                    return
            }
            self.fields.append(CSBRecordStructureField(name: name, dataType: dataType))
        }
    }
    
    public func dataType(forField field: String) -> CSBRecordDataType {
        return fields.filter{$0.name == field}.first?.dataType ?? .text
    }
}
