import Foundation

enum CSBContainerOperationError: Int, Error {
    case onDeleteCSB
    
    var localizedDescription: String {
        switch self {
        case .onDeleteCSB:
            return "Unable to delete the Cloud Safe Box"
        }
    }
}

enum SafeAccessOperationError: Int, Error {
    case onDeleteSafeStore
    case onCouldNotStoreDSeeds
    case onAddNewDSeed
    
    var localizedDescription: String {
        switch self {
        case .onDeleteSafeStore:
            return "Unable to delete Keychain Store"
        case .onCouldNotStoreDSeeds:
            return "Unable to store derived seeds"
        case .onAddNewDSeed:
            return "Unable to add a new derived seed"
        }
    }
}
