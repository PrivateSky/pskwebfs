import Foundation

public struct WizardQuestion {
    public let question: String
    public let answers: Array<String>
    public var correctIndex: Int
}

public class Wizard {

    public var questions: Array<WizardQuestion>
    
    public init() {
        questions = Array<WizardQuestion>()
        if let array = Bundle.arrayFromJson(named: AppFileName.csbWizard.rawValue) {
            array.forEach { (question) in
                if let question = question as? Dictionary<String, Any> {
                    guard let title = question["question"] as? String,
                        let answers = question["answers"] as? Array<String>,
                        let correctIndex = question["correctIndex"] as? Int else { return }
                    questions.append(WizardQuestion(question: title, answers: answers, correctIndex: correctIndex))
                }
            }
        }
    }
    
    public func submit() {
        
    }
}
