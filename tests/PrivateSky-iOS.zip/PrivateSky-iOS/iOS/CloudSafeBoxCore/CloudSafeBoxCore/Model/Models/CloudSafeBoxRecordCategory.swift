//
//  CloudSafeBoxRecords.swift
//  CloudSafeBoxCore
//
//  Created by Catalin Pomirleanu on 6/19/18.
//  Copyright © 2018 Catalin Pomirleanu. All rights reserved.
//

import UIKit

public class CloudSafeBoxRecordCategory: NSObject {

    public let title: String
    public var records: Array<[String : Any]>
    
    public init(title: String) {
        self.title = title
        self.records = []
    }
    
    func addRecord(fields: [(key: String, value: Data, dataType: CSBRecordDataType)]) {
        var newRecord = [String : Any]()
        newRecord["id"] = UUID().uuidString
        fields.forEach { (field) in
            switch field.dataType {
            case .text, .date:
                if let val = String(data: field.value, encoding: .utf8) {
                    newRecord[field.key] = val
                }
            case .document:
                print("handle docs")
            }
        }
        records.append(newRecord)
    }
    
    func updateRecord(fields: [(key: String, value: Data, dataType: CSBRecordDataType)]) {
        guard let recordId = id(fromFields: fields),
            let recordIndex = records.index(where: {($0["id"] as? String) == recordId})
            else { return }
        
        var record = records.filter { ($0["id"] as? String) == recordId }.first
        if record == nil { return }
        
        fields.forEach { (field) in
            switch field.dataType {
            case .text, .date:
                if let val = String(data: field.value, encoding: .utf8) {
                    record![field.key] = val
                }
            case .document:
                print("handle docs")
            }
        }
        if let range = Range(NSRange(location: recordIndex, length: 1)) {
            records.replaceSubrange(range, with: [record!])
        }
    }
    
    func deleteRecord(at index: Int) {
        records.remove(at: index)
    }
    
    private func id(fromFields fields: [(key: String, value: Data, dataType: CSBRecordDataType)]) -> String? {
        let data = fields.filter { $0.key == "id" }.first?.value
        if data == nil { return nil }
        return String(data: data!, encoding: .utf8)
    }
}
