import Foundation

public class CloudSafeBox {
    
    private(set) var id: String
    var version: Int
    var storageProtocolVersion: Int
    public var title: String
    public var localImageName: String
    private(set) var dseed: Data
    public var data: Array<CloudSafeBoxRecordCategory>
    public var shares: Array<String>
    private var localStorageFileName: String
    
    init() {
        id = UUID().uuidString
        version = 1
        storageProtocolVersion = 1
        title = ""
        localImageName = ""
        dseed = Data(count: 1)
        data = []
        shares = []
        localStorageFileName = ""
    }
    
    convenience init(title: String, localImageName: String, seed: String) {
        self.init()
        self.title = title
        self.localImageName = localImageName
        setSeed(seed) {_ in }
    }
    
    convenience init?(data: Data?) {
        guard let data = data,
            let json = try? JSONSerialization.jsonObject(with: data, options: [])
            else { return nil }
        self.init()
        
        if let json = json as? [String: Any] {
            if let id = json["id"] as? String {
                self.id = id
            }
            if let version = json["version"] as? Int {
                self.version = version
            }
            if let storageProtocolVersion = json["storageProtocolVersion"] as? Int {
                self.storageProtocolVersion = storageProtocolVersion
            }
            if let title = json["title"] as? String {
                self.title = title
            }
            if let localImageName = json["localImageName"] as? String {
                self.localImageName = localImageName
            }
            if let dseedBytes = json["dseed"] as? Array<UInt8> {
                self.dseed = Data(bytes: dseedBytes)
            }
            if let shares = json["shares"] as? Array<String> {
                self.shares = shares
            }
            if let recordCategories = json["records"] as? Dictionary<String, Any> {
                for (categoryName, records) in recordCategories {
                    let cat = CloudSafeBoxRecordCategory(title: categoryName)
                    if let records = records as? Array<[String : Any]> {
                        cat.records = records
                    }
                    self.data.append(cat)
                }
            }
            self.localStorageFileName = DependenciesManager.dataBinder().buildEncryptedFileName(from: [title, dseed])
        }
    }
    
    public func setSeed(_ seed: String, completion: (_ success: Bool) -> Void) {
        DependenciesManager.crypter().provideDerivedSeed(from: seed,
                                                         dseedLen: 32) { (derivedSeed) in
                                                            guard let derivedSeed = derivedSeed else { completion(false); return }
                                                            self.dseed = derivedSeed
                                                            self.localStorageFileName = DependenciesManager.dataBinder().buildEncryptedFileName(from: [title, derivedSeed])
                                                            DependenciesManager.sensitiveDataContainer().saveDSeed(forCSB: localStorageFileName, dseed: derivedSeed)
                                                            completion(true)
        }
    }
    
    public func categoryRecords(byTitle title: String) -> Array<[String: Any]>? {
        return data.filter {$0.title == title}.first?.records
    }
    
    public func addRecord(forCategory category: String, fields: [(key: String, value: Data, dataType: CSBRecordDataType)]) {
        let categories = data.filter { $0.title == category }
        if categories.count > 0 {
            categories.forEach { $0.addRecord(fields: fields) }
        } else {
            let newCategory = CloudSafeBoxRecordCategory(title: category)
            newCategory.addRecord(fields: fields)
            data.append(newCategory)
        }
        sendToLocalStorageAsync()
    }
    
    public func updateRecord(forCategory category: String, fields: [(key: String, value: Data, dataType: CSBRecordDataType)]) {
        data.filter { $0.title == category }.forEach { $0.updateRecord(fields: fields) }
        sendToLocalStorageAsync()
    }
    
    public func deleteRecord(forCategory category: String, at index: Int) {
        data.filter { $0.title == category }.forEach { $0.deleteRecord(at: index) }
        sendToLocalStorageAsync()
    }
    
    func sendToLocalStorageAsync() {
        DispatchQueue.main.async { [weak self] in
            self?.sendToLocalStorage(completion: { (success) in })
        }
    }
    
    func sendToLocalStorage(completion: (_ success: Bool) -> Void) {
        var jsonDict = Dictionary<String, Any>()
        jsonDict["id"] = self.id
        jsonDict["version"] = self.version
        jsonDict["storageProtocolVersion"] = self.storageProtocolVersion
        jsonDict["title"] = self.title
        jsonDict["localImageName"] = self.localImageName
        jsonDict["dseed"] = self.dseed.bytes
        jsonDict["shares"] = self.shares
        var records = Dictionary<String, Any>()
        for category in data {
            records[category.title] = category.records
        }
        jsonDict["records"] = records
        do {
            let json = try JSONSerialization.data(withJSONObject: jsonDict, options: .prettyPrinted)
            DependenciesManager.crypter().encrypt(data: json, password: dseed) { (encryptedCSB) in
                guard let encryptedCSB = encryptedCSB else { completion(false); return }
                DependenciesManager.sandbox().writeCSB(named: localStorageFileName, csb: encryptedCSB, completion: completion)
            }
        } catch {
            completion(false)
        }
    }
}
