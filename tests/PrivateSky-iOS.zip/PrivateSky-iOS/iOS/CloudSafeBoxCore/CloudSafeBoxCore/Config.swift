public protocol IConfig {
    func setup()
}

class Config: IConfig {

    func setup() {
        DependenciesManager.sandbox().setupSandbox()
        SensitiveDataContainer.shared.setup()
        DependenciesManager.csbContainer().setupContainer()
    }
}
