public final class DependenciesManager {
    
    public static func config() -> IConfig {
        return Config()
    }
    
    public static func csbContainer() -> ICSBContainer {
        return CSBInMemoryContainer.shared
    }
    
    public static func sensitiveDataContainer() -> ISensitiveDataContainer {
        return SensitiveDataContainer.shared
    }
    
    public static func newCSBForm() -> INewCSBSession {
        return NewCSBSession()
    }
    
    public static func csbRecordsHandler() -> CSBRecordsHandler {
        return CSBRecordsHelper()
    }
    
    public static func crypter() -> Crypter {
        return AESCrypter()
    }
    
    public static func dataBinder() -> IDataBinder {
        return DataBinder()
    }
    
    public static func sandbox() -> Sandbox {
        return SandboxManager()
    }
}
