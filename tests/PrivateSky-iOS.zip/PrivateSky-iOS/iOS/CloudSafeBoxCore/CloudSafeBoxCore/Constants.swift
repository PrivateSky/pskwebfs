let CSB_PASSWORD_MIN_LENGTH = 6
let CSB_PASSWORD_RECOVERY_PHRASE_LENGTH = 24

let CSB_MAIN_DIRECTORY = "cloud_safe_boxes"
let CSB_ATTACHMENTS_DIRECTORY = "attachments"

enum AppFileType: String {
    case txt    = "txt"
    case json   = "json"
}

enum AppFileName: String {
    case csbWizard = "csb_wizard"
}

enum AppDirectoryName: String {
    case csbRecordsStructure = "CSBRecordsStructure"
}
