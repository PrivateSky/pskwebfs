import Foundation

extension Bundle {
    
    static var frameworkBundle: Bundle? {
        return Bundle(identifier: "eu.romsoft.CloudSafeBoxCore")
    }
    
    static func dataFromFile(named resourceName: String, ofType type: AppFileType) throws -> Data? {
        
        guard let path = frameworkBundle?.path(forResource: resourceName, ofType: type.rawValue) else { return nil }
        let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
        return data
    }
    
    static func jsonFromFile(named resourceName: String) throws -> Any? {
        if let data = try dataFromFile(named: resourceName, ofType: .json) {
            let jsonResult = try JSONSerialization.jsonObject(with: data, options: [])
            return jsonResult
        }
        return nil
    }
    
    static func dictionaryFromJson(named resourceName: String) -> Dictionary<String, Any>? {
        do {
            if let jsonResult = try jsonFromFile(named: resourceName) as? Dictionary<String, Any> {
                return jsonResult
            }
            return nil
        } catch {
            return nil
        }
    }
    
    static func arrayFromJson(named resourceName: String) -> Array<Any>? {
        do {
            if let jsonResult = try jsonFromFile(named: resourceName) as? Array<Any> {
                return jsonResult
            }
            return nil
        } catch {
            return nil
        }
    }
}
