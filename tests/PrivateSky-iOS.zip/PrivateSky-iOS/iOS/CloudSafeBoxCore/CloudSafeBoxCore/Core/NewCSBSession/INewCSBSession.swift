public protocol INewCSBSession {
    func add(title: String, imageName: String)
    func addRecoveryPhrase(completion: (_ seed: String) -> Void)
    func add(passcode: String)
    func submit(completion: (_ success: Bool, _ error: Error?) -> Void)
}
