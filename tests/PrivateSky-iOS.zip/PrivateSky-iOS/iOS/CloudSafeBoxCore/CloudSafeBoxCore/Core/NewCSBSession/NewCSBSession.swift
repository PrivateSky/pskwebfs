import Foundation

class NewCSBSession: INewCSBSession {
    
    private let safeBox: CloudSafeBox
    
    init() {
        self.safeBox = CloudSafeBox()
    }
    
    // MARK: - Delegates
    func add(title: String, imageName: String) {
        safeBox.title = title
        safeBox.localImageName = imageName
    }
    
    func addRecoveryPhrase(completion: (_ seed: String) -> Void) {
        let recoveryPhrase = DependenciesManager.dataBinder().buildRandomWords(withCount: 24).joined(separator: "   ")
        safeBox.setSeed(recoveryPhrase) { _ in
            completion(recoveryPhrase)
        }
    }
    
    func add(passcode: String) {
    }
    
    func submit(completion: (_ success: Bool, _ error: Error?) -> Void) {
        DependenciesManager.csbContainer().addCSB(safeBox, completion: completion)
    }
}
