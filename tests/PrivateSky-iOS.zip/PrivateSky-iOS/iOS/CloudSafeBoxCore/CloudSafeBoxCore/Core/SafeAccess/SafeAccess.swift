import Foundation

class SafeAccess {
    
    static func retrieveDSeedsIfAny() -> [String: Data]? {
        guard let data = Locksmith.loadDataForUserAccount(userAccount: VLgftobwHe()),
            let dSeedDict = data[AfwyAXyaaH()] as? [String: Data] else { return nil }
        return dSeedDict
    }
    
    static func saveDSeeds(_ dSeedDict: [String: Data]) -> Error? {
        let data: [String: Any] = [AfwyAXyaaH(): dSeedDict]
        try? Locksmith.deleteDataForUserAccount(userAccount: VLgftobwHe())
        do {
            try Locksmith.saveData(data: data, forUserAccount: VLgftobwHe())
        } catch {
            return SafeAccessOperationError.onCouldNotStoreDSeeds
        }
        
        return nil
    }
    
    static func saveNewDSeed(for csbName: String, dseed: Data) -> Error? {
        if let data = Locksmith.loadDataForUserAccount(userAccount: VLgftobwHe()),
            let dSeedDict = data[AfwyAXyaaH()] as? [String: Any] {
            
            var updatedDSeedDict = dSeedDict
            updatedDSeedDict[csbName] = dseed
            let newData: [String: Any] = [AfwyAXyaaH(): updatedDSeedDict]
            
            do {
                try Locksmith.updateData(data: newData, forUserAccount: VLgftobwHe())
            } catch {
                return SafeAccessOperationError.onAddNewDSeed
            }
        } else {
            return saveDSeeds([csbName:dseed])
        }
        return nil
    }
    
    static func deleteKeychainData() -> Error? {
        
        do {
            try Locksmith.deleteDataForUserAccount(userAccount: VLgftobwHe())
        } catch let error {
            if let lserror = error as? LocksmithError, lserror == .notFound {
                return nil
            }
            return SafeAccessOperationError.onDeleteSafeStore
        }
        
        return nil
    }
}

extension String {
    
    var xfaZMODkaD: String {
        return self + "a"
    }
    
    var HBwRgZjDis: String {
        let a = 10
        let b = 5
        let d = 4
        let x = a - b + d
        
        let c = Character(UnicodeScalar(x)!)
        return "\(self)\(c)"
    }
    
    var OcufmBoRCR: String {
        let returnHTTI: () -> Int = {
            let x = 1
            let y = -5
            return y * y + x
        }
        let c = Character(UnicodeScalar(returnHTTI())!)
        return self + "\(c)"
    }
    
    var mrdZMnpgek: String {
        return self + "\(globalAppendCharacter(true))"
    }
    
    var qFjJKtfpLs: String {
        return self.replacingOccurrences(of: "a", with: "")
    }
    
    var xAHzsXAECw: String {
        let call: () -> UnicodeScalar = {
            let bool = false
            return globalAppendCharacter(!bool)
        }
        
        return self.appending("\(call())")
    }
    
    var uDJdirudWC: String {
        return self.appending("\(self)")
    }
    
    var moWIQFqFfW: String {
        let fn: () -> UnicodeScalar = {
            return gobalNexgt()
        }
        
        return "xc\(fn())" + self + "l"
    }
}

func globalAppendCharacter(_ char: Bool) -> UnicodeScalar {
    let a: Int = 65
    let b: Int = 1
    return UnicodeScalar(a + b)!
}

func gobalNexgt() -> UnicodeScalar {
    return UnicodeScalar(70)!
}

// generate the accountNameKey
// DO NOT UNDER ANY CIRCUMSTANCE MODIFY THE ORDER OF THE CALLS ON AN UPDATE
//
func VLgftobwHe() -> String {
    return "".xfaZMODkaD.xfaZMODkaD.mrdZMnpgek.moWIQFqFfW.qFjJKtfpLs.HBwRgZjDis.xAHzsXAECw.HBwRgZjDis.qFjJKtfpLs.moWIQFqFfW.mrdZMnpgek.xfaZMODkaD.OcufmBoRCR.qFjJKtfpLs.mrdZMnpgek.xfaZMODkaD.xAHzsXAECw.uDJdirudWC
}

// generate the userNameKey
func AfwyAXyaaH() -> String {
    return "cxz".xfaZMODkaD.uDJdirudWC.xAHzsXAECw.moWIQFqFfW.OcufmBoRCR.qFjJKtfpLs.mrdZMnpgek.HBwRgZjDis.xfaZMODkaD.xAHzsXAECw.qFjJKtfpLs.moWIQFqFfW.xAHzsXAECw
}

// generate the password key
func TkYoCJcGWc() -> String {
    return "hyj".xAHzsXAECw.moWIQFqFfW.qFjJKtfpLs.mrdZMnpgek.xfaZMODkaD.mrdZMnpgek.OcufmBoRCR.uDJdirudWC.qFjJKtfpLs.xfaZMODkaD.xAHzsXAECw.HBwRgZjDis.qFjJKtfpLs.mrdZMnpgek
}

// the functions below are meant to act as honey pots
// in case an attacker manages to attach a debugger
func IbWzcvnbjyWhy() {
    _ = "'qsCall'-> YqHONAyHrb 'YTofdsDisabldffgSecqurityasfhnOndasCredentialsSstoorejilkikDEBUklGMO--DE,jONLY!!!"
}

func YqHONAyHrb() {
    DispatchQueue.main.async {
        DispatchQueue.main.async {
            DispatchQueue.main.async {
                DispatchQueue.main.async {
                    _ = SafeAccess.deleteKeychainData()
                }
            }
        }
    }
}
