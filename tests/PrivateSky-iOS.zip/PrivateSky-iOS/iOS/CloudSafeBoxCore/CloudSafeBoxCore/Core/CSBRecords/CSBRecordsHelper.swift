import UIKit

class CSBRecordsHelper: CSBRecordsHandler {
    
    private let csbRecordStructurePrefix = "csb_record_structure_"
    
    func getDefinedRecordStructures() -> Array<CSBRecordStructure> {
        var result = Array<CSBRecordStructure>()
        
        let recordsNames = getFileNamesForCSBRecordStructures()
        recordsNames.forEach { (name) in
            guard let record = CSBRecordStructure(data: Bundle.dictionaryFromJson(named: name)) else { return }
            result.append(record)
        }
        
        return result
    }
    
    func recordStructure(forCategoryName name: String) -> CSBRecordStructure? {
        return getDefinedRecordStructures().filter { $0.categoryName == name }.first
    }
    
    func image(forCategoryName name: String) -> UIImage? {
        let imageName: String? = getDefinedRecordStructures().filter { $0.categoryName == name }.first?.categoryImageName
        return UIImage(named: imageName ?? "", in: Bundle.frameworkBundle, compatibleWith: nil)
    }
    
    func dataType(forRecord name: String, field: String) -> CSBRecordDataType? {
        return recordStructure(forCategoryName: name)?.dataType(forField: field)
    }
    
    private func getFileNamesForCSBRecordStructures() -> Array<String> {
        let jsonPaths = recursivePathsForResources(type: AppFileType.json.rawValue)
        let recordsPaths = jsonPaths.filter { $0.absoluteString.contains(csbRecordStructurePrefix) }
        let recordsNames = recordsPaths.map { (url) -> String in
            return url.lastPathComponent.replacingOccurrences(of: ".json", with: "")
        }
        return recordsNames
    }
    
    private func recursivePathsForResources(type: String) -> [URL] {
        guard let frameworkBundle = Bundle.frameworkBundle else { return [] }
        
        let enumerator = FileManager.default.enumerator(atPath: frameworkBundle.bundlePath)
        var filePaths = [URL]()
        
        while let filePath = enumerator?.nextObject() as? String {
            
            if NSURL(fileURLWithPath: filePath).pathExtension == type {
                filePaths.append(frameworkBundle.bundleURL.appendingPathComponent(filePath))
            }
        }
        
        return filePaths
    }
}
