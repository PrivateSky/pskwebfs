import UIKit
public protocol CSBRecordsHandler {
    func getDefinedRecordStructures() -> Array<CSBRecordStructure>
    func recordStructure(forCategoryName name: String) -> CSBRecordStructure?
    func image(forCategoryName name: String) -> UIImage?
    func dataType(forRecord name: String, field: String) -> CSBRecordDataType?
}
