import Foundation

class SandboxManager: Sandbox {
    
    func setupSandbox() {
        let fileManager = FileManager.default
        let csbDirectoryHierarchyPath = getCSBAttachmentsDirectoryPath()
        if !fileManager.fileExists(atPath: csbDirectoryHierarchyPath.path) {
            do {
                try fileManager.createDirectory(atPath: csbDirectoryHierarchyPath.path, withIntermediateDirectories: true, attributes: nil)
            } catch {
                
            }
        }
    }
    
    func removeAllCSBs() {
        let csbDirectory = getCSBDirectoryURL()
        try? FileManager.default.removeItem(atPath: csbDirectory.path)
    }
    
    func getAllCSBPaths() -> [String] {
        let fileManager = FileManager.default
        guard let documentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return [] }
        let csbDirectoryPath = documentDirectory.appendingPathComponent(CSB_MAIN_DIRECTORY)
        do {
            let csbURLs = try fileManager.contentsOfDirectory(atPath: csbDirectoryPath.path)
            return csbURLs.map { csbDirectoryPath.appendingPathComponent($0) }.map { $0.path }
        } catch {
            return []
        }
    }
    
    func readData(atPath path: String) -> Data? {
        let url = URL(fileURLWithPath: path)
        do {
            return try Data(contentsOf: url)
        } catch {
            return nil
        }
    }
    
    func writeCSB(named name: String, csb: Data, completion: (_ success: Bool) -> Void) {
        let path = URL(fileURLWithPath: getCSBPath(csbName: name))
        writeData(named: name, data: csb, path: path, completion: completion)
    }
    
    func writeCSBAttachment(named name: String, attachment: Data, completion: (_ success: Bool) -> Void) {
        let path = URL(fileURLWithPath: getCSBAttachmentPath(attachmentName: name))
        writeData(named: name, data: attachment, path: path, completion: completion)
    }

    private func writeData(named name: String, data: Data, path: URL, completion: (_ success: Bool) -> Void) {
        do {
            try data.write(to: path, options: Data.WritingOptions.atomic)
            completion(true)
        } catch {
            completion(false)
        }
    }
    
    private func getCSBPath(csbName: String) -> String {
        return getCSBDirectoryURL().appendingPathComponent(csbName).path
    }
    
    private func getCSBAttachmentPath(attachmentName: String) -> String {
        return getCSBAttachmentsDirectoryPath().appendingPathComponent(attachmentName).path
    }
    
    private func getCSBDirectoryURL() -> URL {
        let fileManager = FileManager.default
        guard let documentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "") }
        let csbDirectoryPath = documentDirectory.appendingPathComponent(CSB_MAIN_DIRECTORY)
        return csbDirectoryPath
    }
    
    private func getCSBAttachmentsDirectoryPath() -> URL {
        let fileManager = FileManager.default
        guard let documentDirectory = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first else { return URL(fileURLWithPath: "") }
        let csbDirectoryPath = documentDirectory.appendingPathComponent(CSB_MAIN_DIRECTORY)
        let csbDirectoryAttachmentsPath = csbDirectoryPath.appendingPathComponent(CSB_ATTACHMENTS_DIRECTORY)
        return csbDirectoryAttachmentsPath
    }
}
