import Foundation

public protocol Sandbox {
    func setupSandbox()
    func removeAllCSBs()
    func getAllCSBPaths() -> [String]
    func readData(atPath path: String) -> Data?
    func writeCSB(named name: String, csb: Data, completion: (_ success: Bool) -> Void)
    func writeCSBAttachment(named name: String, attachment: Data, completion: (_ success: Bool) -> Void)
}
