import XCTest

class CSBInMemoryContainerTests: XCTestCase {
    
    let csbContainer = CSBInMemoryContainer.shared
    
    override func setUp() {
        DependenciesManager.sandbox().setupSandbox()
    }
    
    override func tearDown() {
        DependenciesManager.sandbox().removeAllCSBs()
    }
    
    func testSavingAndFetchingCSBFromAppSandbox() {
        let csb = getMockedCSB()
        csbContainer.setupContainer()
        csbContainer.addCSB(csb) { (success, error) in
            if !success {
                XCTFail()
            } else {
                csbContainer.extractCSBsFromSandbox()
                csbContainer.provideCSBList(completion: { (csbs, error) in
                    if error != nil {
                        XCTFail()
                    } else {
                        XCTAssert(csbs.count > 0, "Failed to add Cloud Safe Box to local storage.")
                    }
                })
            }
        }
    }
    
    private func getMockedCSB() -> CloudSafeBox {
        let fullCSB = CloudSafeBox(title: "Personal data",
                                   localImageName: "csbicon01",
                                   seed: "anca asda asduiyai asudyais aisudyaisu asuyd87yqwkj asioudy08q7y daoisudy98qy aydosdy7q asdoi7aq")
        let category = CloudSafeBoxRecordCategory(title: "Notes")
        category.records = [["id": "n1ui2h3w12h5",
                          "Title": "Love Letter",
                          "Notes": "John Gollan loves Ivona Ciollan"]]
        
        fullCSB.data = [category]
        return fullCSB
    }
}
