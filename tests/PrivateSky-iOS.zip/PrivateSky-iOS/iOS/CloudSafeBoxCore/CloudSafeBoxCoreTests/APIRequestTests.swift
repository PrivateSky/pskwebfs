import XCTest

class APIRequestTests: XCTestCase {
    
    private let baseURL = "www.apirequesttest.com"
    
    func testRequestCanBuildWithPath() {
        guard let url = URL(string: baseURL)
            else { XCTFail(); return }
        
        let request = APIRequest(baseURL: url,
                                 path: "/testPaths/1",
                                 method: .get,
                                 reqParameters: APIRequestParams.body(nil),
                                 headers: nil)
        
        guard let urlRequest = request.buildRequest(),
            let urlString = urlRequest.url?.absoluteString
            else { XCTFail(); return }
        
        XCTAssert(urlString == "www.apirequesttest.com/testPaths/1", "The url doesn't contain the correct path")
    }
    
    func testRequestCanBuildWithHeaders() {
        guard let url = URL(string: baseURL)
            else { XCTFail(); return }
        
        let request = APIRequest(baseURL: url,
                                 path: "",
                                 method: .get,
                                 reqParameters: APIRequestParams.body(nil),
                                 headers: ["Authorization":"headerValue"])
        
        guard let urlRequest = request.buildRequest(),
            let headers = urlRequest.allHTTPHeaderFields
            else { XCTFail(); return }
        
        XCTAssert(headers["Authorization"] == "headerValue", "HTTP headers aren't saved in request")
    }
    
    func testRequestCanBuildWithQueryParameters() {
        guard let url = URL(string: baseURL)
            else { XCTFail(); return }
        
        let request = APIRequest(baseURL: url,
                                 path: "",
                                 method: .get,
                                 reqParameters: APIRequestParams.url(["queryParamKey":"queryParamValue"]),
                                 headers: nil)
        
        guard let urlRequest = request.buildRequest(),
            let urlString = urlRequest.url?.absoluteString
            else { XCTFail(); return }
        
        XCTAssert(urlString == "www.apirequesttest.com?queryParamKey=queryParamValue", "Couldn't compute query parameters")
    }
    
    func testRequestCanBuildWithBody() {
        guard let url = URL(string: baseURL)
            else { XCTFail(); return }
        
        let request = APIRequest(baseURL: url,
                                 path: "",
                                 method: .get,
                                 reqParameters: APIRequestParams.body(["bodyKey":"bodyValue"]),
                                 headers: nil)
        
        guard let urlRequest = request.buildRequest(),
            let bodyData = urlRequest.httpBody
            else { XCTFail(); return }
        
        do {
            if let body = try JSONSerialization.jsonObject(with: bodyData, options: []) as? Dictionary<String, Any> {
                XCTAssert((body["bodyKey"] as? String) == "bodyValue", "Couldn't verify body accuracy")
            } else {
                XCTFail()
            }
        } catch {
            XCTFail()
        }
    }
}
