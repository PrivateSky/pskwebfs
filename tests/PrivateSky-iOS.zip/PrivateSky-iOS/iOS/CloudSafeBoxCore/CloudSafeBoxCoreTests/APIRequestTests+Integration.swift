import XCTest

extension APIRequestTests {
    
    func testThatCanRetrieveExternalData() {
        let expectation = self.expectation(description: "Retriving remote data")
        var expectedData: Dictionary<String, Any>?
        
        guard let url = URL(string: "https://swapi.co/api")
            else { XCTFail(); return }
        
        let request = APIRequest(baseURL: url,
                                 path: "/planets/1/",
                                 method: .get,
                                 reqParameters: APIRequestParams.url(["format":"wookiee"]),
                                 headers: nil)
        
        let session = URLSession.shared
        request.sendRequest(from: session) { (data, error) in
            guard error == nil
                else { XCTFail("Error while fetching remote data");
                    return}
            guard let data = data
                else { XCTFail();
                    return }
            
            do {
                let result = try JSONSerialization.jsonObject(with: data, options: []) as? Dictionary<String, Any>
                expectedData = result
                expectation.fulfill()
            } catch {
                XCTFail("Error trying to parse remote data")
            }
        }
        
        waitForExpectations(timeout: 10) { (error) in
            if error != nil {
                XCTFail("Expectation timeout")
            }
        }
        
        XCTAssert(expectedData != nil, "Couldn't retrieve remote data")
    }
}
