import XCTest

class AESCrypterTests: XCTestCase {
    
    let crypter = AESCrypter()
    let defaultEncryptionKey = "12345678"
    let defaultEncryptionKeyData = "12345678".data(using: .utf8)!
    
    func testThatDataCanBeEncrypted() {
        let dataToEncrypt = "Cloud Safe Box Core Framework".data(using: .utf8)!
        crypter.encrypt(data: dataToEncrypt, password: defaultEncryptionKeyData) { (encryptedData) in
            XCTAssertTrue(encryptedData != nil, "Encrypted data is nil.")
        }
    }
    
    func testEncryptionDecryption() {
        let dataToEncrypt = "Cloud Safe Box Core Framework".data(using: .utf8)!
        crypter.encrypt(data: dataToEncrypt, password: defaultEncryptionKeyData) { (encryptedData) in
            guard let encryptedData = encryptedData else { XCTFail(); return }
            crypter.decrypt(encryptedData: encryptedData, password: defaultEncryptionKeyData, completion: { (decryptedData) in
                XCTAssertTrue(decryptedData == dataToEncrypt, "Decrypted data is NOT equal to data to encrypt.")
            })
        }
    }
    
    func testThatSeedCanBeDerived() {
        let seed = "Cloud Safe Box Seed"
        crypter.provideDerivedSeed(from: seed, dseedLen: 32) { (dseed) in
            XCTAssertTrue(dseed != nil, "Derived Seed Bytes are nil.")
        }
    }
    
    func testDSeedEncryptionDecryption() {
        let dseed = "Cloud Safe Box Seed"
        crypter.encryptDSeed(dseed.bytes, pin: defaultEncryptionKey) { (encryptedDSeed) in
            guard let encryptedDSeed = encryptedDSeed else { XCTFail(); return }
            crypter.decryptDSeed(encryptedDSeed, pin: defaultEncryptionKey, completion: { (decryptedDSeed) in
                XCTAssertTrue(decryptedDSeed == dseed, "Decrypted derived seed is NOT equal to initial derived seed.")
            })
        }
    }
    
    func testEncryptionDecryptionTime() {
        self.measure {
            let dataToEncrypt = "Cloud Safe Box Core Framework".data(using: .utf8)!
            crypter.encrypt(data: dataToEncrypt, password: defaultEncryptionKeyData) { (encryptedData) in
                guard let encryptedData = encryptedData else { XCTFail(); return }
                crypter.decrypt(encryptedData: encryptedData, password: defaultEncryptionKeyData, completion: { (decryptedData) in
                    XCTAssertTrue(decryptedData == dataToEncrypt, "Decrypted data is NOT equal to data to encrypt.")
                })
            }
        }
    }
    
    func testDSeedEncryptionDecryptionTime() {
        self.measure {
            let dseed = "Cloud Safe Box Seed"
            crypter.encryptDSeed(dseed.bytes, pin: defaultEncryptionKey) { (encryptedDSeed) in
                guard let encryptedDSeed = encryptedDSeed else { XCTFail(); return }
                crypter.decryptDSeed(encryptedDSeed, pin: defaultEncryptionKey, completion: { (decryptedDSeed) in
                    XCTAssertTrue(decryptedDSeed == dseed, "Decrypted derived seed is NOT equal to initial derived seed.")
                })
            }
        }
    }
}
